<?php
/**
 * @author Eviaglobal_CustomerGraphQl
 * @copyright Copyright (c) 2023 Eviaglobal
 */
declare(strict_types=1);

namespace Eviaglobal\CustomerGraphQl\Model\Resolver;

use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Customer\Api\CustomerMetadataInterface;

class CustomerGroupLabel implements ResolverInterface
{
    /**
     * @var Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $customerRepositoryInterface;

    /**
     * @param Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
     */

    /**
     * @var CustomerMetadataInterface
     */
    protected $customerMetadata;
    public function __construct(
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        CustomerMetadataInterface $customerMetadata
    ) {
        $this->customerRepositoryInterface = $customerRepositoryInterface;
        $this->customerMetadata = $customerMetadata;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        if (!isset($value['model'])) {
            throw new LocalizedException(__('"model" value should be specified'));
        }
        /** @var CustomerInterface $customer */
        $customer = $value['model'];
        $customerId = (int) $customer->getId();
        $customerData = $this->customerRepositoryInterface->getById($customerId);

        /* Get customer custom attribute value */
        if ($customer->getGroupId()) {
            $groupId = $customer->getGroupId();
            $groupLabel['value'] = $groupId;
            foreach($this->getGroupAttribute('group_id')->getOptions() as $option){
                if($option->getValue() === $groupId){
                    $groupLabel['label'] = $option->getLabel();
                }
            }
        } else {
            $groupLabel['value'] = null;
            $groupLabel['label'] = null;
        }

        return $groupLabel;
    }

    /**
     * Retrieve customer attribute instance
     *
     * @param string $attributeCode
     * @return AttributeMetadataInterface|null
     * @throws LocalizedException
     */
    protected function getGroupAttribute($attributeCode)
    {
        try {
            return $this->customerMetadata->getAttributeMetadata($attributeCode);
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }
}
