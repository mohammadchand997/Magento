<?php

namespace Eviaglobal\Project\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const XML_PATH_CREDITS_USED = "transaction/general/credits_used";
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    protected $json;

    /**
    * @var \Magento\Framework\App\Config\ScopeConfigInterface
    */
    protected $scopeConfig;

    /**
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\Serialize\Serializer\Json $json,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ){
        $this->customerSession = $customerSession;
        $this->json = $json;
        $this->scopeConfig = $scopeConfig;
    }

    public function getCustomerTokenObject(){
        return $this->json->serialize($this->customerSession->getCustomerTokenCredentials());
    }

    public function getCreditsUsed(){
        return $this->scopeConfig->getValue(
            self::XML_PATH_CREDITS_USED, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}


