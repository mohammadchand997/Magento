<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class StoreCredentials implements ObserverInterface
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession
    ){
        $this->customerSession = $customerSession;
    }


    public function execute(Observer $observer)
    {
        $password = $observer->getEvent()->getPassword();
        $customerModel = $observer->getEvent()->getModel();
        if($customerModel->getEmail() && $password){
            $this->customerSession->setCustomerTokenCredentials([
                'customerEmail'    => $customerModel->getEmail(),
                'customerPassword' => $password
            ]);
        }else{
            $this->customerSession->unsCustomerTokenCredentials();
        }
        //print_r($this->customerSession->getCustomerTokenCredentials());die();
    }
}


