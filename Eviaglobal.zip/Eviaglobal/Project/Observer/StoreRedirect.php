<?php

declare(strict_types=1);

namespace Eviaglobal\Project\Observer;
use Eviaglobal\Project\Controller\Index\StoreRedirect as StoreRedirectController;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class StoreRedirect implements ObserverInterface
{

    public function __construct(
        StoreRedirectController $storeRedirect,
        CookieManagerInterface $customCookieManager,
        CookieMetadataFactory $customCookieMetadataFactory
    ){
        $this->storeRedirect = $storeRedirect;
        $this->customCookieManager = $customCookieManager;
        $this->customCookieMetadataFactory = $customCookieMetadataFactory;
    }

    public function execute(Observer $observer){
    	
        $this->storeRedirect->execute();
    }

}


