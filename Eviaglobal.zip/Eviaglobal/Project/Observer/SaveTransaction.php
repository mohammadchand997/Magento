<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;

class SaveTransaction implements ObserverInterface
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    private $dateTimeFactory;

    protected $projectCollection;

    protected $transactionModel;

    protected $subscriptionHelper;

    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        DateTimeFactory $dateTimeFactory,
        \Eviaglobal\Project\Model\ResourceModel\Project\CollectionFactory $projectCollectionFactory,
        \Eviaglobal\Subscription\Model\Transaction $transactionModel,
        \Eviaglobal\Project\Helper\Data $subscriptionHelper
    ){
        $this->customerSession = $customerSession;
        $this->dateTimeFactory = $dateTimeFactory;
        $this->projectCollection = $projectCollectionFactory;
        $this->transactionModel = $transactionModel;
        $this->subscriptionHelper = $subscriptionHelper;
    }


    public function execute(Observer $observer){
        
        if (!$this->customerSession->authenticate()) {
            return;
        }
        $dateModel  = $this->dateTimeFactory->create();
        $data = $observer->getEvent()->getScene();
        
        $transactionData = [
            'credits_used' => $this->subscriptionHelper->getCreditsUsed(),
            'project_id'  => $data['parent_id'],
            'project_name'=> $this->getProjectName($data['parent_id']),
            'scene_id'    =>  $data['scene_id'],
            'scene_name'  =>  $data['name'],
            'created_at'  =>  $dateModel->gmtDate('d-m-Y H:i:s')
        ];
        try{
            if($transactionData){
                $this->transactionModel->setData($transactionData);
                $this->transactionModel->save();
            }
        }catch(\Exception $e){
           \Magento\Framework\App\ObjectManager::getInstance()
                ->get('Psr\Log\LoggerInterface')->critical($e->getMessage());
        }
        return $this;
    }

    protected function getProjectName($parentId){
        $collection = $this->projectCollection->create();
        if($parentId){
            $collection->addFieldToFilter('project_id', $parentId);
        }
        $value = $collection->getColumnValues('name');
        return $value[0] ?? '';
    }
}


