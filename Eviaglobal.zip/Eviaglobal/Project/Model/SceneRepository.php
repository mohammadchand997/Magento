<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Model;

use Eviaglobal\Project\Api\Data\SceneInterface;
use Eviaglobal\Project\Api\Data\SceneInterfaceFactory;
use Eviaglobal\Project\Api\Data\SceneSearchResultsInterfaceFactory;
use Eviaglobal\Project\Api\SceneRepositoryInterface;
use Eviaglobal\Project\Model\ResourceModel\Scene as ResourceScene;
use Eviaglobal\Project\Model\ResourceModel\Scene\CollectionFactory as SceneCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class SceneRepository implements SceneRepositoryInterface
{

    /**
     * @var SceneInterfaceFactory
     */
    protected $sceneFactory;

    /**
     * @var SceneCollectionFactory
     */
    protected $sceneCollectionFactory;

    /**
     * @var Scene
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var ResourceScene
     */
    protected $resource;


    /**
     * @param ResourceScene $resource
     * @param SceneInterfaceFactory $sceneFactory
     * @param SceneCollectionFactory $sceneCollectionFactory
     * @param SceneSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceScene $resource,
        SceneInterfaceFactory $sceneFactory,
        SceneCollectionFactory $sceneCollectionFactory,
        SceneSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->sceneFactory = $sceneFactory;
        $this->sceneCollectionFactory = $sceneCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(SceneInterface $scene)
    {
        try {
            $this->resource->save($scene);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the scene: %1',
                $exception->getMessage()
            ));
        }
        return $scene;
    }

    /**
     * @inheritDoc
     */
    public function get($sceneId)
    {
        $scene = $this->sceneFactory->create();
        $this->resource->load($scene, $sceneId);
        if (!$scene->getId()) {
            throw new NoSuchEntityException(__('Scene with id "%1" does not exist.', $sceneId));
        }
        return $scene;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->sceneCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(SceneInterface $scene)
    {
        try {
            $sceneModel = $this->sceneFactory->create();
            $this->resource->load($sceneModel, $scene->getSceneId());
            $this->resource->delete($sceneModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Scene: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($sceneId)
    {
        return $this->delete($this->get($sceneId));
    }
}
