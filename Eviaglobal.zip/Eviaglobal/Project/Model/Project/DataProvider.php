<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Model\Project;

use Eviaglobal\Project\Model\ResourceModel\Project\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager  = $storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
        }
        $data = $this->dataPersistor->get('eviaglobal_project_project');
        $imageName = '';
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('eviaglobal_project_project');
        }
        
        if(isset($model) && isset($this->loadedData[$model->getId()])){
            $imageName = $this->loadedData[$model->getId()]['image'];
            unset($this->loadedData[$model->getId()]['image']);
            $this->loadedData[$model->getId()]['general']['name'] = $this->loadedData[$model->getId()]['name'];
            $this->loadedData[$model->getId()]['general']['image'][0]['url'] = $this->getMediaUrl().$imageName;
            $this->loadedData[$model->getId()]['general']['image'][0]['name'] = $imageName;
            $this->loadedData[$model->getId()]['general']['image'][0]['type'] = 'image/png';
            $this->loadedData[$model->getId()]['general']['image'][0]['size'] = 1234;
            $this->loadedData[$model->getId()]['general']['image'][0]['exists'] = 1;
        }
        //echo "<pre>";print_r($this->loadedData);die();
        return $this->loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'tmp/imageUploader/images/';
        return $mediaUrl;
    }
}

