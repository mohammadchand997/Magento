<?php

namespace Eviaglobal\Project\Model\ResourceModel\Zone;
/**
 * Description of Collection
 *
 * @author Evia Global
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
     /**
     * @var string
     */
    protected $_idFieldName = 'zone_id';
	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init(
                   'Eviaglobal\Project\Model\Zone', 
                    'Eviaglobal\Project\Model\ResourceModel\Zone'
                );
                
                $this->_map['fields']['zone_id'] = 'main_table.zone_id';
	}

}