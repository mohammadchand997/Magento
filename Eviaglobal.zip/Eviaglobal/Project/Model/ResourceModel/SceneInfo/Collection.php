<?php

namespace Eviaglobal\Project\Model\ResourceModel\SceneInfo;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
     /**
     * @var string
     */
    protected $_idFieldName = 'scene_info_id';
	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init(
                    'Eviaglobal\Project\Model\SceneInfo', 
                    'Eviaglobal\Project\Model\ResourceModel\SceneInfo'
                );
                
                $this->_map['fields']['scene_info_id'] = 'main_table.scen_info_id';
	}

}