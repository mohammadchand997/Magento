<?php

namespace Eviaglobal\Project\Model\ResourceModel;

/**
 * Description of Material
 *
 * @author EviaGlobal
 */
class Material extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('eviaglobal_scene_item_zone_material', 'material_id');
    }
}