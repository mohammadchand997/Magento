<?php

namespace Eviaglobal\Project\Model\ResourceModel;

/**
 * Description of Zone
 *
 * @author Evia Global
 */
class Zone extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('eviaglobal_scene_item_zone', 'zone_id');
    }
}