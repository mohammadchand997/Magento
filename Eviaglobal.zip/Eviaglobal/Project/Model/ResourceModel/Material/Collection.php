<?php

namespace Eviaglobal\Project\Model\ResourceModel\Material;

/**
 * Description of Collection
 *
 * @author Evia Global
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
     /**
     * @var string
     */
    protected $_idFieldName = 'material_id';
	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init(
                    'Eviaglobal\Project\Model\Material', 
                    'Eviaglobal\Project\Model\ResourceModel\Material'
                );
                
                $this->_map['fields']['material_id'] = 'main_table.material_id';
	}

}