<?php

namespace Eviaglobal\Project\Model\ResourceModel;

/**
 * Description of SceneInfo
 *
 * @author EviaGlobal
 */
class SceneInfo extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('eviaglobal_scene_info', 'scene_info_id');
    }
}