<?php

namespace Eviaglobal\Project\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

/**
 * Description of UpdateScene
 *
 * @author Eviaglobal
 */
class UpdateScene implements ResolverInterface
{
    /**
     * 
     * @var  \Eviaglobal\Project\Model\Resolver\DataProvider\UpdateSceneDataProvider
     */
    private $updateSceneDataProvider;

    /**
     * 
     * @param \Eviaglobal\Project\Model\Resolver\DataProvider\UpdateSceneDataProvider $updateSceneDataProvider
     */
    public function __construct(
        \Eviaglobal\Project\Model\Resolver\DataProvider\UpdateSceneDataProvider $updateSceneDataProvider
    ) {
        $this->updateSceneDataProvider = $updateSceneDataProvider;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        /** @var ContextInterface $context */
        if (false === $context->getExtensionAttributes()->getIsCustomer()) {
            throw new GraphQlAuthorizationException(__('The current customer isn\'t authorized.'));
        }
        
        $success_message =  $this->updateSceneDataProvider->execute($args);
       
        return  $success_message;
       
    }
} 
