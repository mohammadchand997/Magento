<?php

namespace Eviaglobal\Project\Model\Resolver\DataProvider;

class SaveSceneDataProvider
{
    /**
     * 
     * @var \Eviaglobal\Project\Model\SceneFactory
     */
    private $sceneFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\SceneInfoFactory
     */
    private $sceneInfoFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\ZoneFactory
     */
    private $zoneFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\MaterialFactory
     */
    private $materialFactory;
    
    /**
     * 
     * @param \Eviaglobal\Project\Model\SceneFactory $sceneFactory
     * @param \Eviaglobal\Project\Model\SceneInfoFactory $sceneInfoFactory
     * @param \Eviaglobal\Project\Model\ZoneFactory $zoneFactory
     * @param \Eviaglobal\Project\Model\MaterialFactory $materialFactory
     */
    public function __construct(
        \Eviaglobal\Project\Model\SceneFactory $sceneFactory,
        \Eviaglobal\Project\Model\SceneInfoFactory $sceneInfoFactory,  
        \Eviaglobal\Project\Model\ZoneFactory $zoneFactory,   
        \Eviaglobal\Project\Model\MaterialFactory $materialFactory   
    ) {
        $this->sceneFactory = $sceneFactory;
        $this->sceneInfoFactory = $sceneInfoFactory;
        $this->zoneFactory = $zoneFactory;
        $this->materialFactory = $materialFactory;
    }
    public function execute($input){
        try {
            if(!empty($input['scene_info_data'][0])){
                $sceneId = $this->addScene($input['scene_info_data'][0]); 
                foreach($input['product_info_data'] as $product){
                    $this->addSceneInfo($product, $sceneId); 
                }
                $response['message'] = "Scene Details Saved Successfully.";
            }else{
                $response['message'] = "invalid request.";
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        
        return $response;
    }
    
    public function addScene($input){
        try {
            $sceneFactory = $this->sceneFactory->create();
            if(isset($input['scene_name'])){
                $sceneFactory->setName($input['scene_name']);
            }
            if(isset($input['project_id'])){
                $sceneFactory->setParentId($input['project_id']);
            }
            if(isset($input['image'])){
                $sceneFactory->setImage($input['image']);
            }
            if(isset($input['length'])){
                $sceneFactory->setLength($input['length']);
            }
            if(isset($input['width'])){
                $sceneFactory->setWidth($input['width']);
            }
            if(isset($input['height'])){
                $sceneFactory->setHeight($input['height']);
            }
            if(isset($input['products'])){
                $sceneFactory->setProducts($input['products']);
            }
            $sceneFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $sceneFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
            if($sceneFactory->save()){
                $lastInsertedId = $sceneFactory->getId();
                return $lastInsertedId;
            }
            else{
                return false;
            }
         } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
    
    public function addSceneInfo($input, $id){
        try{
            $sceneInfoFactory = $this->sceneInfoFactory->create();
            $sceneInfoFactory->setSceneId($id);
            if(isset($input['position'])){
                $sceneInfoFactory->setPosition($input['position']);
            }
            if(isset($input['rotation'])){
                $sceneInfoFactory->setRotation($input['rotation']);
            }
            if(isset($input['position_locked'])){
                $sceneInfoFactory->setPositionLocked($input['position_locked']);
            }
            if(isset($input['product_id'])){
                $sceneInfoFactory->setProductId($input['product_id']);
            }
            $sceneInfoFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $sceneInfoFactory->setUpdatedAt(date("Y-m-d h:i:sa"));

            if($sceneInfoFactory->save()){
                $sceneInfoId = $sceneInfoFactory->getId();
                foreach($input['zone'] as $zone){
                    $this->addZone($zone, $sceneInfoId);
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
    
    public function addZone($input, $sceneInfoId){
        try{
            $zoneFactory = $this->zoneFactory->create();
            $zoneFactory->setZoneName($input['zone_name']);
            $zoneFactory->setSceneInfoId($sceneInfoId);
            if(isset($input['product_zone_id'])){
                $zoneFactory->setProductZoneId($input['product_zone_id']);
            }
            $zoneFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $zoneFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
            $zoneFactory->save();
            $zoneId = $zoneFactory->getId();
            foreach($input['material'] as $material){
                $this->addZoneMaterial($material,$zoneId );
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        
    }
    
    public function addZoneMaterial($input, $zoneId){
        try{
            $materialFactory = $this->materialFactory->create();
            $materialFactory->setData($input);
            $materialFactory->setZoneId($zoneId);
            $materialFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $materialFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
            $materialFactory->save();
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
}
