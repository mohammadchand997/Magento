<?php

namespace Eviaglobal\Project\Model\Resolver\DataProvider;

class Scene
{
    private $sceneFactory;

     public function __construct(
          \Eviaglobal\Project\Model\SceneFactory $sceneFactory
     ) {
          $this->sceneFactory = $sceneFactory;
     }

    public function getRecords($projectId)
    {
        try {
            $collection = $this->sceneFactory->create()->getCollection();
            if($projectId){
                $collection->addFieldToFilter('parent_id', $projectId);
            }
            $scenes = $collection->getData();

        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return $scenes;
    }
}