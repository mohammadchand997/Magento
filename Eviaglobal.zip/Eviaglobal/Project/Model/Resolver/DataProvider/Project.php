<?php

namespace Eviaglobal\Project\Model\Resolver\DataProvider;

class Project
{
    private $projectFactory;

     public function __construct(
          \Eviaglobal\Project\Model\ProjectFactory $projectFactory
     ) {
          $this->projectFactory = $projectFactory;
     }

    public function getRecords($customerId)
    {
        try {
            $collection = $this->projectFactory->create()->getCollection();
            if($customerId){
                $collection->addFieldToFilter('customer_id', $customerId);
            }
            $projects = $collection->getData();

        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return $projects;
    }
}