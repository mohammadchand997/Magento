<?php

namespace Eviaglobal\Project\Model\Resolver\DataProvider;

/**
 * Description of UpdateSceneDataProvider
 *
 * @author Eviaglobal
 */
class UpdateSceneDataProvider
{
   /**
     * 
     * @var \Eviaglobal\Project\Model\SceneFactory
     */
    private $sceneFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\SceneInfoFactory
     */
    private $sceneInfoFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\ZoneFactory
     */
    private $zoneFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\MaterialFactory
     */
    private $materialFactory;
    
    /**
     * 
     * @param \Eviaglobal\Project\Model\SceneFactory $sceneFactory
     * @param \Eviaglobal\Project\Model\SceneInfoFactory $sceneInfoFactory
     * @param \Eviaglobal\Project\Model\ZoneFactory $zoneFactory
     * @param \Eviaglobal\Project\Model\MaterialFactory $materialFactory
     */
    public function __construct(
        \Eviaglobal\Project\Model\SceneFactory $sceneFactory,
        \Eviaglobal\Project\Model\SceneInfoFactory $sceneInfoFactory,  
        \Eviaglobal\Project\Model\ZoneFactory $zoneFactory,   
        \Eviaglobal\Project\Model\MaterialFactory $materialFactory   
    ) {
        $this->sceneFactory = $sceneFactory;
        $this->sceneInfoFactory = $sceneInfoFactory;
        $this->zoneFactory = $zoneFactory;
        $this->materialFactory = $materialFactory;
    }
    public function execute($input){
        try {
            if(!empty($input)){
                foreach($input['update_scene_info'] as $scene){
                    $res = $this->updateScene($scene);
                    if($res !== true){
                       $response['message'] = $res;
                       return $response;
                    }
                }
                $response['message'] = "scene updated successfully.";
            }else{
                $response['message'] = "invalid request.";
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return $response;
    }
    
    public function updateScene($input){
        try {
            $sceneFactory = $this->sceneFactory->create()->load($input['scene_id']);
            if(!empty($sceneFactory->getData()) && $sceneFactory->getParentId() == $input['project_id']){
                if(isset($input['scene_name'])){
                    $sceneFactory->setSceneName($input['scene_name']);
                }
                if(isset($input['image'])){
                    $sceneFactory->setImage($input['image']);
                }
                if(isset($input['length'])){
                    $sceneFactory->setLength($input['length']);
                }
                if(isset($input['width'])){
                    $sceneFactory->setWidth($input['width']);
                }
                if(isset($input['height'])){
                    $sceneFactory->setHeight($input['height']);
                }
                if(isset($input['products'])){
                    $sceneFactory->setProducts($input['products']);
                }
                $sceneFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
                $sceneFactory->save();
                if(isset($input['update_products_info'])){
                    foreach($input['update_products_info'] as $products){
                        $res = $this->updateSceneInfo($products, $input['scene_id']);
                        if($res !== true){
                        return $res;
                     }
                    }
                    return true;
                }
                else{
                    return "invalid Scene Id ".$input['scene_id'];
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
    
    public function updateSceneInfo($input, $id){
        try{
            if($input['add_product'] == 1){
               return $this->addSceneInfo($input, $id);
            }else{
                $sceneInfoFactory = $this->sceneInfoFactory->create()
                                ->load($input['scene_info_id']);
                if(!empty($sceneInfoFactory->getData()) && $sceneInfoFactory->getData('scene_id') == $id){               
                    if(isset($input['position'])){
                        $sceneInfoFactory->setPosition($input['position']);
                    }
                    if(isset($input['rotation'])){
                        $sceneInfoFactory->setRotation($input['rotation']);
                    }
                    if(isset($input['position_locked'])){
                        $sceneInfoFactory->setPositionLocked($input['position_locked']);
                    }
                    if(isset($input['product_id'])){
                        $sceneInfoFactory->setProductId($input['product_id']);
                    }
                    $sceneInfoFactory->setUpdatedAt(date("Y-m-d h:i:sa"));

                    if($sceneInfoFactory->save()){
                        foreach($input['update_zone'] as $zone){
                           $res = $this->updateZone($zone, $input['scene_info_id']);
                           if($res !== true){
                                return $res;
                           }
                        }
                    }
                 return true;
                }
                else{
                   return "invalid Scene info Id ".$input['scene_info_id'];
                }
            }

        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
    
    public function updateZone($input, $sceneInfoId){
        try{
            if($input['add_zone'] == 1){
                return $this->addZone($input, $sceneInfoId);
            }else{
                $zoneFactory = $this->zoneFactory->create()
                                ->load($input['zone_id']);
                if(!empty($zoneFactory->getData()) && $zoneFactory->getSceneInfoId() == $sceneInfoId){
                    if(isset($input['zone_name'])){
                        $zoneFactory->setZoneName($input['zone_name']);
                    }
                    if(isset($input['product_zone_id'])){
                        $zoneFactory->setProductZoneId($input['product_zone_id']);
                    }
                    $zoneFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
                    $zoneFactory->save();
                    foreach($input['material'] as $material){
                       $res = $this->updateZoneMaterial($material, $input['zone_id']);
                       if($res !== true){
                        return $res;
                       }
                    }
                    return true;
                }
                else{
                     return "invalid Zone Id ".$input['zone_id'];
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        
    }
    
    public function updateZoneMaterial($input, $zoneId){
        try{
             if($input['add_material'] == 1){
                return $this->addZone($input, $zoneId);
            }else{
                $materialFactory = $this->materialFactory->create()
                                ->load($input['material_id']);
                if(!empty($materialFactory->getData()) && $materialFactory->getZoneId() == $zoneId){               
                    if(isset($input['material_name'])){
                        $materialFactory->setMaterialName($input['material_name']);
                    }
                    if(isset($input['product_material_id'])){
                        $materialFactory->setProductMaterialId($input['product_material_id']);
                    }
                    if(isset($input['price_type'])){
                        $materialFactory->setPriceType($input['price_type']);
                    }
                    if(isset($input['area'])){
                        $materialFactory->setArea($input['area']);
                    }
                    if(isset($input['price'])){
                        $materialFactory->setPrice($input['price']);
                    }
                    $materialFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
                    $materialFactory->save();
                    return true;
                }else{
                    return "invalid material Id ".$input['material_id'];
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
    
    public function addSceneInfo($input, $id){
        try{
            unset($input['scene_info_id']);

            $sceneInfoFactory = $this->sceneInfoFactory->create();
            $sceneInfoFactory->setSceneId($id);
            if(isset($input['position'])){
                $sceneInfoFactory->setPosition($input['position']);
            }
            if(isset($input['rotation'])){
                $sceneInfoFactory->setRotation($input['rotation']);
            }
            if(isset($input['position_locked'])){
                $sceneInfoFactory->setPositionLocked($input['position_locked']);
            }
            if(isset($input['product_id'])){
                $sceneInfoFactory->setProductId($input['product_id']);
            }
            $sceneInfoFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $sceneInfoFactory->setUpdatedAt(date("Y-m-d h:i:sa"));

            if($sceneInfoFactory->save()){
                $sceneInfoId = $sceneInfoFactory->getId();
                foreach($input['update_zone'] as $zone){
                    $res = $this->addZone($zone, $sceneInfoId);
                    if($res !== true){
                        return $res;
                    }
                }
                return true;
            }else{
                    return "invalid product request";
                }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
    
    public function addZone($input, $sceneInfoId){
        try{
            unset($input['zone_id']);
            $zoneFactory = $this->zoneFactory->create();
            $zoneFactory->setZoneName($input['zone_name']);
            $zoneFactory->setSceneInfoId($sceneInfoId);
            if(isset($input['product_zone_id'])){
                $zoneFactory->setProductZoneId($input['product_zone_id']);
            }
            $zoneFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $zoneFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
            if($zoneFactory->save()){
                $zoneId = $zoneFactory->getId();
                foreach($input['material'] as $material){
                    $res = $this->addZoneMaterial($material,$zoneId );
                    if($res !== true){
                        return $res;
                    }
                    return true;
                }
            }else{
                 return "invalid zone request";
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        
    }
    
    public function addZoneMaterial($input, $zoneId){
        try{
            unset($input['material_id']);
            $materialFactory = $this->materialFactory->create();
            $materialFactory->setData($input);
            $materialFactory->setZoneId($zoneId);
            $materialFactory->setCreatedAt(date("Y-m-d h:i:sa"));
            $materialFactory->setUpdatedAt(date("Y-m-d h:i:sa"));
            if($materialFactory->save()){
                return true;
            }else{
                return "invalid material request.";
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
    }
}