<?php

namespace Eviaglobal\Project\Model\Resolver\DataProvider;

class GetSceneById
{
    /**
     * 
     * @var \Eviaglobal\Project\Model\SceneFactory
     */
    private $sceneFactory;
    
    /**
     * @var \Eviaglobal\Project\Model\ProjectFactory
     */
    private $projectFactory;
    
    /**
     * 
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;
    
    /**
     * 
     * @var \Magento\Catalog\API\ProductRepositoryInterface
     */
    protected $productRepository;
    
    /**
     * 
     * @var \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory
     */
    protected $optionFactory;
    
    /**
     * 
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManagerInterface;
    
    /**
     * @var \Magento\Directory\Model\CurrencyFactory
     */
    private $currencyCode;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\SceneInfoFactory
     */
    private $sceneInfoFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\ZoneFactory
     */
    private $zoneFactory;
    
    /**
     * 
     * @var \Eviaglobal\Project\Model\MaterialFactory
     */
    private $materialFactory;

    /**
     * 
     * @param \Eviaglobal\Project\Model\SceneFactory $sceneFactory
     * @param \Eviaglobal\Project\Model\ProjectFactory $projectFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Catalog\API\ProductRepositoryInterface $productRepository
     * @param \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeConfig
     * @param \Magento\Directory\Model\CurrencyFactory $currencyFactory
     * @param \Eviaglobal\Project\Model\SceneInfoFactory $sceneInfoFactory
     * @param \Eviaglobal\Project\Model\ZoneFactory $zoneFactory
     * @param \Eviaglobal\Project\Model\MaterialFactory $materialFactory
     */
    public function __construct(
        \Eviaglobal\Project\Model\SceneFactory $sceneFactory,
        \Eviaglobal\Project\Model\ProjectFactory $projectFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\API\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionFactory,
        \Magento\Store\Model\StoreManagerInterface $storeConfig,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Eviaglobal\Project\Model\SceneInfoFactory $sceneInfoFactory,  
        \Eviaglobal\Project\Model\ZoneFactory $zoneFactory,   
        \Eviaglobal\Project\Model\MaterialFactory $materialFactory   
    ) {
        $this->sceneFactory = $sceneFactory;
        $this->projectFactory = $projectFactory;
        $this->_productFactory = $productFactory;
        $this->productRepository = $productRepository;
        $this->optionFactory = $optionFactory;
        $this->storeConfig = $storeConfig;
        $this->currencyCode = $currencyFactory;
        $this->sceneInfoFactory = $sceneInfoFactory;
        $this->zoneFactory = $zoneFactory;
        $this->materialFactory = $materialFactory;
    }

    public function getRecords($params)
    {
        try {
            $projectCollection = $this->projectFactory->create()->getCollection();
            $collection = $this->sceneFactory->create()->getCollection();
            $projectData = $projectCollection->addFieldToFilter('project_id', $params['project_id'])->getData();
            $projectData[0]['project_name'] = $projectData[0]['name'];
            unset($projectData[0]['name']);
            if(!empty($projectData)) {
                $collection->addFieldToFilter('scene_id', $params['scene_id'])
                    ->addFieldToFilter('parent_id', $params['project_id']);
                $data = $collection->getData();
                if(empty($data)){
                    $result['status'] = 0;
                    $result['message'] = 'No record found with the given scene id.';
                }else{
                    $data[0]['scene_name'] = $data[0]['name'];
                    unset($data[0]['name']);
                     $data[0]['created_on'] = $data[0]['created_at'];
                    unset($data[0]['created_at']);
                     $data[0]['last_modified'] = $data[0]['updated_at'];
                    unset($data[0]['updated_at']);
                    $data[0]['products'] = $this->getProducts($params['scene_id']);
                    
                    $result['status'] = 1;
                    $result['data'] = array_merge($projectData[0],$data[0]);
                }
           }else{
                $result['status'] = 0;
                $result['message'] = 'No record found with the given project id.';
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
       return $result;
    }
    
    public function getProducts($sceneId){
        $sceneInfoFactory = $this->sceneInfoFactory->create()->getCollection();
        $sceneInfoData =  $sceneInfoFactory->addFieldToFilter('scene_id', $sceneId)->getData();
        $i = 0;
        $products = [];
        foreach($sceneInfoData as $item){
            $products[$i] = $this->getProductData($item['product_id']);
            $products[$i] = array_merge($products[$i],$item);
            $products[$i]['zone'] = $this->getZone($item['scene_info_id']);
            $i++;
        }
       return $products;
    }
    
     public function getZone($sceneInfoId){
        $zoneFactory = $this->zoneFactory->create()->getCollection();
        $zoneData = $zoneFactory->addFieldToFilter('scene_info_id', $sceneInfoId)->getData();
        $zones = [];
        $i = 0;
        foreach($zoneData as $zone){
            $zones[$i] = $zone;
            $zones[$i]['material'] = $this->getMaterial($zone['zone_id']);
            $i++;
        }
        return $zones;
     }
     
    public function getMaterial($zoneId){
        $materialFactory = $this->materialFactory->create()->getCollection();
        $materialData = $materialFactory->addFieldToFilter('Zone_id', $zoneId)->getData();
        //print_r($materialData);
        $data = [];
        $i = 0;
        foreach($materialData as $info){
            if(isset($info["sku"])){
                $item = $this->getMaterialInfo($info['sku']);
                $data[$i] = array_merge($info,$item);
            }
            $i++;
        }
        return $data;
       
    }
    
    public function getProductData($id){
        $loadProduct = $this->_productFactory->create()->load($id);
        $item['product_name'] = $loadProduct->getName();
        $item['product_id'] = $loadProduct->getEntityId();
        $item['product_url'] = $loadProduct->getUrlKey();
        $item['sku'] = $loadProduct->getSku();
        $item['price'] = $loadProduct->getPrice();
        $item ['currency'] = $this->getCurrentCurrency();
        $item['length'] = $loadProduct->getProductLength();
        $item['width'] = $loadProduct->getProductWidthDepth();
        $item['height'] = $loadProduct->getProductHeight();
        $item['is_customizable'] = $loadProduct->getIsCustomizable();
        $item['gltf_file'] = $loadProduct->getGltfFile();
        $item['product_placement'] = $loadProduct->getResource()->getAttribute('placement')->getFrontend()->getValue($loadProduct);
        return $item;
    }
    
    public function getCurrentCurrency(){
        $currentCurrency = $this->storeConfig->getStore()->getCurrentCurrencyCode();
        $currency = $this->currencyCode->create()->load($currentCurrency);
        return $currency->getCurrencyCode();
    }
    public function getMaterialInfo($sku){
        try {
            $item = $this->productRepository->get($sku);
            $product['number_of_unit'] = $item->getNumberOfItems();
            $product['sbsar'] = $item->getSbsarFile();
            $product['material_type'] = $item->getResource()->getAttribute('material_type')->getFrontend()->getValue($item);
            $product['material_color'] = $item->getResource()->getAttribute('material_color')->getFrontend()->getValue($item);
            $product['albedo_texture'] = $item->getAlbedoColor();
            $product['bump_texture'] = null;
            $product['metallic_roughness_texture'] = $item->getRoughnessValue();
        } catch (\Exception $exception) {
        throw new \Magento\Framework\Exception\NoSuchEntityException(__("Such product doesn't exist"));
        }
        return $product;
    }
}
