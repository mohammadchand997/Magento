<?php

namespace Eviaglobal\Project\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class SaveScene implements ResolverInterface
{
    /**
     * 
     * @var  \Eviaglobal\Project\Model\Resolver\DataProvider\SaveSceneDataProvider
     */
    private $saveSceneDataProvider;

    /**
     * 
     * @param \Eviaglobal\Project\Model\Resolver\DataProvider\SaveSceneDataProvider $saveSceneDataProvider
     */
    public function __construct(
        \Eviaglobal\Project\Model\Resolver\DataProvider\SaveSceneDataProvider $saveSceneDataProvider
    ) {
        $this->saveSceneDataProvider = $saveSceneDataProvider;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        /** @var ContextInterface $context */
        if (false === $context->getExtensionAttributes()->getIsCustomer()) {
            throw new GraphQlAuthorizationException(__('The current customer isn\'t authorized.'));
        }
        
        $success_message =  $this->saveSceneDataProvider->execute($args);
        return  $success_message;
       
    }
} 
