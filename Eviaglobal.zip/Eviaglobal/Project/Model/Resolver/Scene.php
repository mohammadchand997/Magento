<?php

namespace Eviaglobal\Project\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class Scene implements ResolverInterface
{
    private $projectDataProvider;

    public function __construct(
        \Eviaglobal\Project\Model\Resolver\DataProvider\GetSceneById $getSceneByIdDataProvider
    ) {
        $this->getSceneByIdDataProvider = $getSceneByIdDataProvider;
    }

    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        /** @var ContextInterface $context */
        if (false === $context->getExtensionAttributes()->getIsCustomer() && $args['edit_mode'] == 1) {
            throw new GraphQlAuthorizationException(__('The current customer isn\'t authorized.'));
        }

        if(!isset($args['project_id'])){
            throw new GraphQlAuthorizationException(__('project id is not passed.'));
        }
        if(!isset($args['scene_id'])){
            throw new GraphQlAuthorizationException(__('scene id is not passed.'));
        }
        if($args['edit_mode'] == 0 || $args['edit_mode'] == 1){
            
            $sceneDetails = $this->getSceneByIdDataProvider->getRecords($args);

            if($sceneDetails['status'] == 1){

                return $sceneDetails['data'];
            }else{
                throw new GraphQlAuthorizationException(__($sceneDetails['message']));
            }
        }else{
            throw new GraphQlAuthorizationException(__('Unauthorized request.'));
        }

    }
}
