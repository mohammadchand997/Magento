<?php

namespace Eviaglobal\Project\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class Scenes implements ResolverInterface
{
    private $sceneDataProvider;

    public function __construct(
        \Eviaglobal\Project\Model\Resolver\DataProvider\Scene $sceneDataProvider
    ) {
        $this->sceneDataProvider = $sceneDataProvider;
    }

    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $projectId = isset($value['project_id']) ? $value['project_id'] : '';
        $scenes = $this->sceneDataProvider->getRecords($projectId);
        return $scenes;
    }
}