<?php

namespace Eviaglobal\Project\Plugin\Catalog\Model\Config\Source\Product\Options;

class Price{
     /**
     * {@inheritdoc}
     *
     * @codeCoverageIgnore
     */
    public function afterToOptionArray(
        \Magento\Catalog\Model\Config\Source\Product\Options\Price $subject,
        array  $priceTypeOption
    ){
        $priceTypeOption[] = ['value' => 'custom', 'label' => __('Custom')];
        return $priceTypeOption;
    }
}

