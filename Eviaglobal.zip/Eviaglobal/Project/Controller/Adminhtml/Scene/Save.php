<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Controller\Adminhtml\Scene;

use Psr\Log\LoggerInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;

class Save extends \Magento\Backend\App\Action
{

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    private $dataObjectHelper;


    private $dateTimeFactory;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        LoggerInterface $logger,
        JsonFactory $resultJsonFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        DateTimeFactory $dateTimeFactory
    ) {
        parent::__construct($context);
        $this->logger            = $logger;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataObjectHelper  = $dataObjectHelper;
        $this->dateTimeFactory = $dateTimeFactory;
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute(): Json
    {
        $sceneId    = $this->getRequest()->getParam('scene_id', false);
        $postedData = $this->getRequest()->getParams();
        $dateModel  = $this->dateTimeFactory->create();
        
        $error   = false;
        try{
            $model = $this->_objectManager->create(\Eviaglobal\Project\Model\Scene::class)->load($sceneId);
            
            if (!$model->getId() && $sceneId) {
                $error = true;
                $message = __('This scene no longer exists.');
            }
            $data = [
                'name'       => $postedData['name'],
                'parent_id'  => $postedData['parent_id'],
                'image'      => $postedData['image'][0]['name'],
                'products'   => $postedData['project_products']
            ];
            
            if($sceneId){
                $data['scene_id']   = $sceneId;
                $data['updated_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
            }else{
                $data['created_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
                $data['updated_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
            }
            $model->setData($data);
            $model->save();
            if ($sceneId) {
                $message = __('Project scene has been updated.');
            } else {
                $message = __('New scene has been added.');
            }
            
        } catch (NoSuchEntityException $e) {
            $this->logger->critical($e);
            $error = true;
            $message = __('There is no scene with such id.');
        } catch (LocalizedException $e) {
            $error = true;
            $message = __($e->getMessage());
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $error = true;
            $message = __('We can\'t change project scene right now :- '.$e->getMessage());
            $this->logger->critical($e);
        }
        $sceneId    = empty($sceneId) ? null : $sceneId;
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'messages' => $message,
                'error' => $error,
                'data' => [
                    'scene_id' => $sceneId
                ]
            ]
        );

        return $resultJson;
    }
}

