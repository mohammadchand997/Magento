<?php
declare(strict_types=1);

namespace Eviaglobal\Project\Controller\Adminhtml\Scene;

use Magento\Backend\App\Action;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Eviaglobal\Project\Api\SceneRepositoryInterface;
use Psr\Log\LoggerInterface;

/**
 * Button for deletion of brand Collection in admin
 */
class Delete extends Action implements HttpPostActionInterface
{

    /**
     * @var SceneRepositoryInterface
     */
    private $sceneRepository;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Action\Context $context
     * @param SceneRepositoryInterface $sceneRepository
     * @param JsonFactory $resultJsonFactory
     * @param LoggerInterface $logger
     */
    public function __construct(
        Action\Context $context,
        SceneRepositoryInterface $sceneRepository,
        JsonFactory $resultJsonFactory,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->sceneRepository   = $sceneRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
    }

    /**
     * Delete project scene action
     *
     * @return Json
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(): Json
    {
        $projectId = $this->getRequest()->getParam('project_id', false);
        $sceneId = $this->getRequest()->getParam('scene_id', false);
        $error = false;
        $message = '';
        
        if ($sceneId && $this->collectionRepository->get($sceneId)->getProjectId() === $projectId) {
            try {
                $this->sceneRepository->deleteById($sceneId);
                $message = __('You deleted the scene.');
            } catch (\Exception $e) {
                $error = true;
                $message = __('We can\'t delete the scene right now.');
                $this->logger->critical($e);
            }
        }

        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'message' => $message,
                'error' => $error,
            ]
        );

        return $resultJson;
    }
}
