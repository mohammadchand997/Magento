<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Controller\Adminhtml\Project;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    private $dateTimeFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        DateTimeFactory $dateTimeFactory
    ) {
        $this->dataPersistor   = $dataPersistor;
        $this->dateTimeFactory = $dateTimeFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $dateModel      = $this->dateTimeFactory->create();
        $data = $this->getRequest()->getPostValue();
        
        $modelData = [];
        $modelData['image'] = isset($data) ? $data['general']['image'][0]['name'] : '';
        $modelData['name']  = isset($data) ? $data['general']['name'] : '';
        //echo "<pre>";print_r($modelData);die();
        if ($data) {
            $id = $this->getRequest()->getParam('project_id');
            if($id){
                $modelData['updated_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
            }else{
                $modelData['created_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
                $modelData['updated_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
            }
            $model = $this->_objectManager->create(\Eviaglobal\Project\Model\Project::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Project no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
        
            $model->setData($modelData);
        
            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the Project.'));
                $this->dataPersistor->clear('eviaglobal_project_project');
        
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['project_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Project.'));
            }
        
            $this->dataPersistor->set('eviaglobal_project_project', $data);
            return $resultRedirect->setPath('*/*/edit', ['project_id' => $this->getRequest()->getParam('project_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}

