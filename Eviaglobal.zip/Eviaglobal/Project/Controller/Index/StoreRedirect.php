<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Controller\Index;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Store\Api\StoreCookieManagerInterface;
use Magento\Store\Api\StoreRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Controller\ResultFactory;
use Mageplaza\StoreSwitcher\Model\RuleFactory;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;

class StoreRedirect implements HttpGetActionInterface
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * Customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * Constructor
     *
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        PageFactory $resultPageFactory,
        \Magento\Customer\Model\Session $customerSession,
        StoreCookieManagerInterface $storeCookieManager,
        StoreRepositoryInterface $storeRepository,
        StoreManagerInterface $storeManager,
        ResultFactory $resultFactory,
        RuleFactory $StoreSwitcherRule,
        RedirectInterface $redirect,
        CookieManagerInterface $customCookieManager,
        CookieMetadataFactory $customCookieMetadataFactory

    ){
        $this->resultPageFactory = $resultPageFactory;
        $this->customerSession = $customerSession;
        $this->_storeCookieManager = $storeCookieManager;
        $this->_storeRepository = $storeRepository;
        $this->_storeManager = $storeManager;
        $this->resultFactory = $resultFactory;
        $this->StoreSwitcherRule = $StoreSwitcherRule;
        $this->redirect = $redirect;
        $this->customCookieManager = $customCookieManager;
        $this->customCookieMetadataFactory = $customCookieMetadataFactory;

    }

    public function execute()
    {   
        $om = \Magento\Framework\App\ObjectManager::getInstance();
        $remoteAddress = $om->get('Magento\Framework\HTTP\PhpEnvironment\RemoteAddress');
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$remoteAddress->getRemoteAddress()));

        $selected_country = '';
        if($ipdat && $ipdat->geoplugin_countryCode != null){
           $selected_country = $ipdat->geoplugin_countryCode;
        }

        $getcustomcookie = $this->customCookieManager->getCookie('customercookie');

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT); 

        if($selected_country != $getcustomcookie){

            $customCookieMetadata = $this->customCookieMetadataFactory->createPublicCookieMetadata();
            $customCookieMetadata->setDurationOneYear();
            $customCookieMetadata->setPath('/');
            $customCookieMetadata->setHttpOnly(false);

            $this->customCookieManager->setPublicCookie(
                'customercookie',
                $selected_country,
                $customCookieMetadata
            );

            $result = $this->getSelectedCountry($selected_country);

            $this->setStoreAndCurrency($result);
        }
        

        $resultRedirect->setUrl($this->redirect->getRefererUrl());
        return $resultRedirect;
    }

    public function getSelectedCountry($selected_country){

        $result = $this->StoreSwitcherRule->create();
        $collection = $result->getCollection();
        $getdata = $collection->getData();

        $getInfo = [];
        foreach ($getdata as $value) {
            $countries = explode(",", $value['countries']);
            if (in_array($selected_country, $countries)){

                $getInfo['store_ids'] = $value['store_ids'];
                $getInfo['currency'] = $value['currency'];
            }

        }

        return $getInfo;

    }

    public function setStoreAndCurrency($result = ''){
        if($result){

            $storeData = $this->_storeManager->getStore($result['store_ids']);
            $storeCode = (string)$storeData->getCode();
            $this->_storeManager->getStore()->setCurrentCurrencyCode($result['currency']);
            $store = $this->_storeRepository->getActiveStoreByCode($storeCode);
            $this->_storeCookieManager->setStoreCookie($store);
        }else{
            $this->_storeManager->getStore()->setCurrentCurrencyCode('USD');
            $store = $this->_storeRepository->getActiveStoreByCode('default');
            $this->_storeCookieManager->setStoreCookie($store);
        }

    }
}

