<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Controller\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\UrlInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;

class Save extends \Magento\Framework\App\Action\Action
{

    /**
     * Customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
    *
    * @var UploaderFactory
    */
    protected $uploaderFactory;

    /** 
    * @var Filesystem\Directory\WriteInterface 
    */
    protected $mediaDirectory;
  
   /**
    * @var StoreManagerInterface
    */
    protected $storeManager;

    private $dateTimeFactory;

    /**
     * Constructor
     *
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        UploaderFactory $uploaderFactory,
        Filesystem $filesystem,
        StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session $customerSession,
        DateTimeFactory $dateTimeFactory
    ){
        parent::__construct($context);
        $this->uploaderFactory = $uploaderFactory;
        $this->mediaDirectory  = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->storeManager    = $storeManager;
        $this->customerSession = $customerSession;
        $this->dateTimeFactory = $dateTimeFactory;
    }

    /**
     * Execute view action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        if (!$this->customerSession->authenticate()) {
            $this->_actionFlag->set('', 'no-dispatch', true);
        }
        $post = $this->getRequest()->getParams();
        
        $projectId  = $this->getRequest()->getParam('project_id', false);

        if (!$post) {
            $this->_redirect('*/*/');
            return;
        }

        $fieldName  = 'project_file';
        $dateModel  = $this->dateTimeFactory->create();
        try {
            $fileUploader = $this->uploaderFactory->create(['fileId' => $fieldName]);
            $fileUploader->setAllowedExtensions(['jpg','jpeg','png']);
            $fileUploader->setAllowRenameFiles(true);
            $fileUploader->setAllowCreateFolders(true);
            $fileUploader->setFilesDispersion(false);
            $fileUploader->validateFile();
            $result = $fileUploader->save($this->mediaDirectory->getAbsolutePath('project/files'));
            
            //Save project data
            $model = $this->_objectManager->create(\Eviaglobal\Project\Model\Project::class)->load($projectId);
            if (!$model->getId() && $projectId) {
                $error = true;
                $message = __('This project no longer exists.');
            }
            $data = [
                'name'       => $post['project_name'],
                'image'      => $result['file'] ?? '',
                'customer_id' => $this->customerSession->getCustomer()->getId()
            ];
            if($projectId){
                $data['project_id'] = $projectId;
                $data['updated_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
            }else{
                $data['created_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
                $data['updated_at'] = $dateModel->gmtDate('d-m-Y H:i:s');
            }
            $model->setData($data);
            $model->save();
            if ($projectId) {
                $message = __('Project has been updated.');
            } else {
                $message = __('New project has been added.');
            }
            $this->messageManager->addSuccessMessage(__($message));
            $this->_redirect('*/');
            return;
        } catch (LocalizedException $e) {
            echo $e->getMessage();die();
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        } catch (\Exception $e) {
            echo $e->getMessage();die();
            $this->messageManager->addErrorMessage(__('An error occurred, please try again later. , ',$e->getMessage()));
        }
        $this->_redirect('*/');
    }
}

