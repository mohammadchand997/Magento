<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProjectRepositoryInterface
{

    /**
     * Save Project
     * @param \Eviaglobal\Project\Api\Data\ProjectInterface $project
     * @return \Eviaglobal\Project\Api\Data\ProjectInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Project\Api\Data\ProjectInterface $project
    );

    /**
     * Retrieve Project
     * @param string $projectId
     * @return \Eviaglobal\Project\Api\Data\ProjectInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($projectId);

    /**
     * Retrieve Project matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Project\Api\Data\ProjectSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Project
     * @param \Eviaglobal\Project\Api\Data\ProjectInterface $project
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Project\Api\Data\ProjectInterface $project
    );

    /**
     * Delete Project by ID
     * @param string $projectId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($projectId);
}

