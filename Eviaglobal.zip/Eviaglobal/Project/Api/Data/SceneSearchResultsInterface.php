<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Api\Data;

interface SceneSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Scene list.
     * @return \Eviaglobal\Project\Api\Data\SceneInterface[]
     */
    public function getItems();

    /**
     * Set name list.
     * @param \Eviaglobal\Project\Api\Data\SceneInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}