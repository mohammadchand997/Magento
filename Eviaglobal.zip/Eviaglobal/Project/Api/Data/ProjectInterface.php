<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Api\Data;

interface ProjectInterface
{

    const NAME = 'name';
    const UPDATED_AT = 'updated_at';
    const PROJECT_ID = 'project_id';
    const CREATED_AT = 'created_at';
    const IMAGE = 'image';

    /**
     * Get project_id
     * @return string|null
     */
    public function getProjectId();

    /**
     * Set project_id
     * @param string $projectId
     * @return \Eviaglobal\Project\Project\Api\Data\ProjectInterface
     */
    public function setProjectId($projectId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Eviaglobal\Project\Project\Api\Data\ProjectInterface
     */
    public function setName($name);

    /**
     * Get image
     * @return string|null
     */
    public function getImage();

    /**
     * Set image
     * @param string $image
     * @return \Eviaglobal\Project\Project\Api\Data\ProjectInterface
     */
    public function setImage($image);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Eviaglobal\Project\Project\Api\Data\ProjectInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Eviaglobal\Project\Project\Api\Data\ProjectInterface
     */
    public function setUpdatedAt($updatedAt);
}

