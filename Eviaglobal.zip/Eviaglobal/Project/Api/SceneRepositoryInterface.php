<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SceneRepositoryInterface
{

    /**
     * Save Scene
     * @param \Eviaglobal\Project\Api\Data\SceneInterface $scene
     * @return \Eviaglobal\Project\Api\Data\SceneInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Project\Api\Data\SceneInterface $scene
    );

    /**
     * Retrieve Scene
     * @param string $sceneId
     * @return \Eviaglobal\Project\Api\Data\SceneInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($sceneId);

    /**
     * Retrieve Scene matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Project\Api\Data\SceneSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Scene
     * @param \Eviaglobal\Project\Api\Data\SceneInterface $scene
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Project\Api\Data\SceneInterface $scene
    );

    /**
     * Delete Scene by ID
     * @param string $sceneId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($sceneId);
}
