<?php
declare(strict_types=1);

namespace Eviaglobal\Project\Block\Adminhtml\Edit\Scene;

use Eviaglobal\Project\Model\SceneFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Eviaglobal\Project\Model\ResourceModel\Scene\Collection;
use Eviaglobal\Project\Model\SceneRepository;

/**
 * Class for common code for buttons on the create/edit address form
 */
class GenericButton
{
    /**
     * @var sceneFactory
     */
    private $sceneFactory;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var scene
     */
    private $sceneResourceModel;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var sceneRepository
     */
    private $sceneRepository;

    /**
     * @param AddressFactory $addressFactory
     * @param UrlInterface $urlBuilder
     * @param Address $addressResourceModel
     * @param RequestInterface $request
     * @param AddressRepository $addressRepository
     */
    public function __construct(
        SceneFactory $sceneFactory,
        UrlInterface $urlBuilder,
        Collection $sceneResourceModel,
        RequestInterface $request,
        SceneRepository $sceneRepository
    ) {
        $this->sceneFactory = $sceneFactory;
        $this->urlBuilder = $urlBuilder;
        $this->sceneResourceModel = $sceneResourceModel;
        $this->request = $request;
        $this->sceneRepository = $sceneRepository;
    }

    /**
     * Return scene Id.
     *
     * @return int|null
     */
    public function getsceneId()
    {
        $scene = $this->sceneFactory->create();

        $sceneId = $this->request->getParam('scene_id');
        $this->sceneResourceModel->load(
            $scene,
            $sceneId
        );

        return $scene->getsceneId() ?: null;
    }

    /**
     * Get customer id.
     *
     * @return int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getProjectId()
    {
        $sceneId = $this->request->getParam('scene_id');

        $scene = $this->sceneRepository->get($sceneId);

        return $scene->getParentId() ?: null;
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', array $params = []): string
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
}
