<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Block;


class Listing extends \Magento\Framework\View\Element\Template
{
    protected $projectCollection;

    protected $customerSession;

    protected $storeManager;

    protected $sceneCollection;

    protected $serializer;

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eviaglobal\Project\Model\ResourceModel\Project\CollectionFactory $collectionFactory,
        \Eviaglobal\Project\Model\ResourceModel\Scene\CollectionFactory $sceneCollectionFactory,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Serialize\SerializerInterface $serializer,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->projectCollection = $collectionFactory;
        $this->sceneCollection = $sceneCollectionFactory;
        $this->customerSession = $customerSession;
        $this->storeManager    = $storeManager;
        $this->serializer      = $serializer;
    }

    public function getPostActionUrl()
    {
        return $this->getUrl('project/index/save');
    }

    public function getProjects(){
        $collection = $this->projectCollection->create();
        $customerId = $this->customerSession->getCustomer()->getId();
        if($customerId){
            $collection->addFieldToFilter('customer_id', $customerId);
        }
        $q = $this->getRequest()->getParam('q');
        if($q){
            $collection->addFieldToFilter('name', ['like' => "%{$q}%"]);
        }
        return $collection;
    }

    public function getProjectImageUrl($project){
        if(!$project){
            return '';
        }
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'/project/files/'.$project->getImage();
    }

    public function getNumOfScenesProducts($project){
        if(!$project){
            return '';
        }
        $collection = $this->sceneCollection->create();
        $collection->addFieldToFilter('parent_id', $project->getId());
        $data = [];
        $flag = $serializeProducts = 0;
        foreach($collection as $_scene){
            $flag++;
            if($_scene->getProducts()){
                $serializeProducts += count($this->serializer->unserialize($_scene->getProducts()));
            }
        }
        
        $data['scenes'] = $flag;
        $data['products'] = $serializeProducts;
        $serializeProducts = 0;
        return $data;
    }
}

