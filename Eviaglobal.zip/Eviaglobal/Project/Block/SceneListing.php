<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Project\Block;


class SceneListing extends \Magento\Framework\View\Element\Template
{
    protected $projectCollection;

    protected $customerSession;

    protected $storeManager;

    protected $sceneCollection;

    protected $serializer;

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eviaglobal\Project\Model\ResourceModel\Scene\CollectionFactory $sceneCollectionFactory,
        \Eviaglobal\Project\Model\ResourceModel\Project\CollectionFactory $projectCollectionFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Serialize\SerializerInterface $serializer,
        array $data = []
    ){
        parent::__construct($context, $data);
        $this->sceneCollection = $sceneCollectionFactory;
        $this->projectCollection = $projectCollectionFactory;
        $this->storeManager    = $storeManager;
        $this->serializer      = $serializer;
    }

    public function getProjectName(){
        $collection = $this->projectCollection->create();
        if($projectId = $this->getProjectId()){
            $collection->addFieldToFilter('project_id', $projectId);
        }
        $value = $collection->getColumnValues('name');
        return $value[0] ?? '';
    }

    public function getProjectId(){
        return $this->getRequest()->getParam('id');
    }

    public function getPostActionUrl()
    {
        return $this->getUrl('project/scene/save');
    }

    public function getScenes(){
        $projectId = $this->getRequest()->getParam('id');
        $collection = $this->sceneCollection->create();
        if($projectId){
            $collection->addFieldToFilter('parent_id', $projectId);
        }
        $q = $this->getRequest()->getParam('q');
        if($q){
            $collection->addFieldToFilter('name', ['like' => "%{$q}%"]);
        }
        
        return $collection;
    }

    public function getSceneImageUrl($scene){
        if(!$scene){
            return '';
        }
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'/scene/files/'.$scene->getImage();
    }

}

