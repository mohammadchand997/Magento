<?php
declare(strict_types=1);

namespace Eviaglobal\Catalog\Model\ResourceModel\Catalog;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'catalog_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Eviaglobal\Catalog\Model\Catalog::class,
            \Eviaglobal\Catalog\Model\ResourceModel\Catalog::class
        );
    }
}

