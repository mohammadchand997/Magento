<?php
declare(strict_types=1);

namespace Eviaglobal\Catalog\Model\Catalog;

use Eviaglobal\Catalog\Model\ResourceModel\Catalog\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Eviaglobal\Brand\Model\BrandFactory;
use Eviaglobal\Brand\Model\CollectionFactory as BrandCollectionFactory;
use Magento\Directory\Model\ResourceModel\Region\Collection  as RegionCollection;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    private $regionCollection;


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        \Magento\Directory\Model\CountryFactory $countryFactory,
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        BrandFactory $brandFactory,
        BrandCollectionFactory $brandCollectionFactory,
        RegionCollection $regionCollection,
        array $meta = [],
        array $data = []
    ) {
        $this->_countryFactory = $countryFactory;
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->brandFactory = $brandFactory;
        $this->brandCollectionFactory = $brandCollectionFactory;
        $this->regionCollection = $regionCollection;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {

            $getBrand = $this->getBrandById($model->getData('brand_id'));
            $brand_id = $getBrand->getData('title');

            $getBrandCollection = $this->getBrandCollectionById($model->getData('collection_id'));
            $collection_id = $getBrandCollection->getData('title');

            $country_id = $this->getCountryname($model->getData('country_id'));
            $region_id = $this->getRegionNameById($model->getData('region_id'));

            $data = $model->getData();
            $data['brand_id'] = $brand_id;
            $data['collection_id'] = $collection_id;
            $data['country_id'] = $country_id;
            $data['region_id'] = $region_id;

            $this->loadedData[$model->getId()] = $data;
        }
        $data = $this->dataPersistor->get('eviaglobal_catalog_catalog');
        
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('eviaglobal_catalog_catalog');
        }
        
        return $this->loadedData;
    }

    public function getBrandById($id)
    {
        return $this->brandFactory->create()->load($id);
    }

    public function getBrandCollectionById($id)
    {
        return $this->brandCollectionFactory->create()->load($id);
    }

    public function getCountryname($countryCode){    
        $country = $this->_countryFactory->create()->loadByCode($countryCode);
        return $country->getName();
    }

    public function getRegionNameById($id)
    {
        $region = $this->regionCollection->getItemById($id);

        return $region->getName();
    }
}

