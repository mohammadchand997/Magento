<?php
declare(strict_types=1);

namespace Eviaglobal\Catalog\Controller\Adminhtml\Catalog;

use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Eviaglobal\Catalog\Model\ResourceModel\Catalog\CollectionFactory;

class MassDeleteCatalog extends \Magento\Backend\App\Action
{

    /**
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        \Eviaglobal\Catalog\Model\CatalogFactory $catalogFactory,
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->catalogFactory = $catalogFactory;
        parent::__construct($context);
    }

    /**
     * Inline edit action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());

            $count = 0;
            foreach ($collection as $model) {
                $model = $this->catalogFactory->create()->load($model->getCatalogId());
                $model->delete();
                $count++;
            }
            $this->messageManager->addSuccess(__('A total of %1 Catalog(s) have been deleted.', $count));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/');
    }
}

