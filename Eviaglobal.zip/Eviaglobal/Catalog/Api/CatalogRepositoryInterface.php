<?php
declare(strict_types=1);

namespace Eviaglobal\Catalog\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface CatalogRepositoryInterface
{

    /**
     * Save catalog
     * @param \Eviaglobal\Catalog\Api\Data\CatalogInterface $catalog
     * @return \Eviaglobal\Catalog\Api\Data\CatalogInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Catalog\Api\Data\CatalogInterface $catalog
    );

    /**
     * Retrieve catalog
     * @param string $catalogId
     * @return \Eviaglobal\Catalog\Api\Data\CatalogInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($catalogId);

    /**
     * Retrieve catalog matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Catalog\Api\Data\CatalogSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete catalog
     * @param \Eviaglobal\Catalog\Api\Data\CatalogInterface $catalog
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Catalog\Api\Data\CatalogInterface $catalog
    );

    /**
     * Delete catalog by ID
     * @param string $catalogId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($catalogId);
}

