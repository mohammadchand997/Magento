<?php
declare(strict_types=1);

namespace Eviaglobal\Product\Observer\Backend\Catalog;

class ProductSaveAfter implements \Magento\Framework\Event\ObserverInterface
{

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {

        $product = $observer->getData('product');
        $attributes = array('countries', 'city', 'custom_supplier');
        foreach ($attributes as $attribute) {
                $attributeValue = $product->getData($attribute);
                $product->setData($attribute, $attributeValue);
        }
    }
}
