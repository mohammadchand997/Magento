<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Product\Observer\Backend\Catalog;

class ProductSaveBefore implements \Magento\Framework\Event\ObserverInterface
{

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {

        $product = $observer->getData('product');
        $attributes = array('custom_supplier_collection', 'countries', 'city', 'is_customizable', 'custom_supplier');
        foreach ($attributes as $attribute) {
                $attributeValue = $product->getData($attribute);
                $product->setData($attribute, $attributeValue);
        }

        // $asjia = $product->setData('countries', 'collection3');
        // echo '<pre>';
        // var_du
        // die;
    }
}
