require([
    'jquery'
], function ($) {
    'use strict';
    jQuery(document).ready(function(){
        jQuery(document).ajaxStop(function () {
            jQuery('select[name=product\\[city\\]]').prop("disabled",true);
        });
    });
});