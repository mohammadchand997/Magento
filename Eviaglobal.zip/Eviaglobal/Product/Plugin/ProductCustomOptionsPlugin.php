<?php
namespace Eviaglobal\Product\Plugin;

class ProductCustomOptionsPlugin
{
    public function afterGetOptions(\Magento\Catalog\Model\Product $subject, $result)
    {
        // $isSimpleConfigurations = $subject->getData('is_independent');

        $isSimpleConfigurations = $subject->getResource()->getAttribute('is_independent')->getFrontend()->getValue($subject);

        // Update the custom options based on the condition
        if ($isSimpleConfigurations == 'No') {
            foreach ($result as $option) {
                $option->setIsRequire(false);
            }
        }

        return $result;
    }
}
