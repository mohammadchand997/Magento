<?php
declare(strict_types=1);

namespace Eviaglobal\Product\Model\Product\Attribute\Source;
use Eviaglobal\Brand\Model\BrandFactory;

class City extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{

    public function __construct(
        BrandFactory $brandFactory
    ){
      $this->brandFactory = $brandFactory;
    }

    /**
     * getAllOptions
     *
     * @return array
     */
    public function getAllOptions()
    {
        $brands = $this->brandFactory->create();
        $brandCollection = $brands->getCollection();
        $getBrands = $brandCollection->getData();
        // $cities = array_unique($getCities);

        // echo '<pre>';
        // print_r($getCities);
        // die;

        $optionsArray = [];
        foreach ($getBrands as $value) {
            $optionsArray[] = [
                'label' => $value['city'],
                'value' => $value['brand_id'],
            ];
        }
        return $optionsArray;
    }
}

