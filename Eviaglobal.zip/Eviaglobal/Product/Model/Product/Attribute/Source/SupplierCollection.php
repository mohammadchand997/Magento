<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Product\Model\Product\Attribute\Source;

use Eviaglobal\Brand\Model\BrandFactory;
use Eviaglobal\Brand\Model\CollectionFactory;
use Magento\Framework\App\ResourceConnection;

class SupplierCollection extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{

    public function __construct(
        BrandFactory $brandFactory,
        CollectionFactory $brandCollectionFactory,
        ResourceConnection $Resource
    ){
      $this->brandFactory = $brandFactory;
      $this->brandCollectionFactory = $brandCollectionFactory;
      $this->_resource = $Resource;
    }

    /**
     * getAllOptions
     *
     * @return array
     */
    // public function getAllOptions()
    // {
    //     $this->_options = [
    //     ['value' => 'collection1', 'label' => __('collection1')],
    //     ['value' => 'collection2', 'label' => __('collection2')],
    //     ['value' => 'collection3', 'label' => __('collection3')]
    //     ];
    //     return $this->_options;
    // }

    public function getAllOptions($flag=true)
    {

        // $options = [

        //     'group1' => [
        //         'label' => 'Group 1',
        //         'value' => [
        //             ['label' => 'Option 1', 'value' => 'option_1'],
        //             ['label' =>'Option 2', 'value' => 'option_2'],
        //         ],
        //     ],
        //     'group2' => [
        //         'label' => 'Group 2',
        //         'value' => [
        //             ['label' =>'Option 3', 'value' => 'option_3'],
        //             ['label' =>'Option 4', 'value' => 'option_4'],
        //         ],
        //     ],
        // ];

        $options = $this->getData($flag);

        $optionsArray = [];
        foreach ($options as $groupKey => $groupData) {
            $optionsArray[] = [
                'label' => $groupData['label'],
                'value' => $groupData['value'],
            ];
        }

        

        return $optionsArray;
    }

    public function getData($flag){
        
        $barndData = $this->brandFactory->create()->getCollection();
        $getData = [];
        foreach ($barndData as $key => $barnd) {
            $id =  $barnd->getId();
            $data['label'] = $barnd->getTitle();
            $getBrandCollections = $this->getBrandCollectionById($id);

            $getCollectionData = [];
            foreach ($getBrandCollections as $key => $collection) {

                    if ($flag) {
                        $dataCollection['label'] = $collection['title'];
                        $dataCollection['value'] = $collection['collection_id'];
                    } else {
                        $dataCollection['label'] = $data['label'].'/'.$collection['title'];
                        $dataCollection['value'] = $collection['collection_id'];
                    }
                    
                    array_push($getCollectionData, $dataCollection);
            }
            $data['value'] = $getCollectionData;
            if($getCollectionData){
                array_push($getData, $data);
            }
            
        }
        // echo "<pre>";
        // print_r($getData);
        // die;

        return $getData;

    }

    public function getBrandCollectionById($id){
        
        $collection = $this->brandCollectionFactory->create()->getCollection()->addFieldToFilter('parent_id', $id);
        return $collection->getData();

    }
}
