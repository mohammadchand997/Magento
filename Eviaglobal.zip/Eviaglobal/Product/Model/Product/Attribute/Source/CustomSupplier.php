<?php
declare(strict_types=1);

namespace Eviaglobal\Product\Model\Product\Attribute\Source;

use Eviaglobal\Brand\Model\BrandFactory;

class CustomSupplier extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    protected $brandFactory;
    public function __construct(
        BrandFactory $brandFactory
    ){
      $this->brandFactory = $brandFactory;
    }

    /**
     * getAllOptions
     *
     * @return array
     */
    public function getAllOptions()
    {
        $barndData = $this->brandFactory->create()->getCollection();
        $getData = [];
        foreach ($barndData as $key => $barnd) {
            $data['value'] =  $barnd->getId();
            $data['label'] = $barnd->getTitle();
            array_push($getData, $data);
        }
        // $this->_options = [
        // ['value' => '1', 'label' => __('collection1')],
        // ['value' => '2', 'label' => __('collection2')],
        // ['value' => '3', 'label' => __('collection3')]
        // ];
        return $getData;
    }
}

