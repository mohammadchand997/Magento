<?php
declare(strict_types=1);

namespace Eviaglobal\Product\Model\Product\Attribute\Source;
use Magento\Directory\Model\ResourceModel\Country\CollectionFactory;

class Country extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    public function __construct(
        CollectionFactory $countryCollectionFactory
    ){
      $this->_countryCollectionFactory = $countryCollectionFactory;
    }

    /**
     * getAllOptions
     *
     * @return array
     */
    public function getAllOptions()
    {
        $countries = $this->_countryCollectionFactory->create()->loadByStore();
    
        $optionsArray = [];
        $index = 1;
        foreach ($countries as $country) {
            $optionsArray[] = [
                'label' => $country->getName(),
                'value' => $index++,
            ];
        }
        return $optionsArray;
        // $this->_options = [
        // ['value' => 'collection1', 'label' => __('collection1')],
        // ['value' => 'collection2', 'label' => __('collection2')],
        // ['value' => 'collection3', 'label' => __('collection3')]
        // ];
        // return $this->_options;
    }
}

