<?php

namespace Eviaglobal\AdvancedProductOptions\Observer;

use Magento\Framework\Event\ObserverInterface;
use MageWorx\OptionDependency\Model\ResourceModel\Config as dependencyManager;
use Magento\Catalog\Model\Product\Option;
 
class PriceChangeAfterAddtoCart implements ObserverInterface
{
    /**
     * @var dependencyManager
     */
    protected $dependencyManager;

    /**
     * @var option
     */
    protected $option;

    /**
     * ForeignKeyChecker constructor.
     *
     * @param ForeignKeyInstallProcess $foreignKeyInstallProcess
     */
    public function __construct(
        dependencyManager $dependencyManager,
        Option $option
    ) {
        $this->dependencyManager = $dependencyManager;
        $this->option = $option;
    }


    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
        /* Code here */
        $quote_item = $observer->getEvent()->getQuoteItem();
        $price = 400; //set your price here
        $product = $quote_item->getProduct();
        $buyRequest = (array)$quote_item->getBuyRequest()->getOptions();
        if($buyRequest){
            $customOptions = $this->option->getProductOptionCollection($product);
            $productOptions = [];
            foreach($customOptions as $option){
                foreach($option->getValues() as $optionValue){
                    $productOptions[$option->getId()][$optionValue->getId()]['area'] = $optionValue->getArea();
                }
            }
            $dependencies = (array) $this->dependencyManager->loadDependencies(
                                                    $product->getId(), 
                                                    [
                                                        'dp_child_option_id',
                                                        'dp_child_option_type_id',
                                                        'dp_parent_option_id',
                                                        'dp_parent_option_type_id'
                                                    ]
                                                );
            $dependenciesAssoc = [];
            foreach($dependencies as $dependency){
                $dependenciesAssoc[$dependency['dp_child_option_id']][$dependency['dp_child_option_type_id']] = [
                    'dp_parent_option_id' => $dependency['dp_parent_option_id'],
                    'dp_parent_option_type_id' => $dependency['dp_parent_option_type_id']
                ]; 
                
            }
            foreach($buyRequest as $selectdOptionId => $selectdOptionValue){
                if(isset($dependenciesAssoc[$selectdOptionId][$selectdOptionValue])){
                    $parentOptionId      = $dependenciesAssoc[$selectdOptionId][$selectdOptionValue]['dp_parent_option_id'];
                    $parentOptionValueId = $dependenciesAssoc[$selectdOptionId][$selectdOptionValue]['dp_parent_option_type_id'];

                    $selectedOptionArea = $productOptions[$parentOptionId][$parentOptionValueId]['area'];
                     \Magento\Framework\App\ObjectManager::getInstance()
                        ->get(\Psr\Log\LoggerInterface::class)->debug($selectedOptionArea, [$selectedOptionArea]);
                        \Magento\Framework\App\ObjectManager::getInstance()
                        ->get(\Psr\Log\LoggerInterface::class)->debug('Product Final Price', [$product->getPrice()]);
                }
            } 
        }
        \Magento\Framework\App\ObjectManager::getInstance()
                    ->get(\Psr\Log\LoggerInterface::class)->debug('productOptions', [$productOptions]);
        \Magento\Framework\App\ObjectManager::getInstance()
                    ->get(\Psr\Log\LoggerInterface::class)->debug('dependenciesAssoc', [$dependenciesAssoc]);

        
        

        
        
        //$quote_item->setCustomPrice($price);
        //$quote_item->setOriginalCustomPrice($price);
        //$quote_item->getProduct()->setIsSuperMode(true);      
    }
}
