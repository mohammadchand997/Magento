<?php

namespace Eviaglobal\AdvancedProductOptions\Observer;

use Magento\Framework\Event\ObserverInterface;
 
class ProductSaveAfter implements ObserverInterface
{
    /**
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
    protected $stockItemRepository;

    /**
     * @var Magento\Framework\App\ResourceConnection
     */
    protected $resource;

    public function __construct(
        \Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository,
        \Magento\Framework\App\ResourceConnection $resource
    ){
        $this->stockItemRepository = $stockItemRepository;
        $this->resource            = $resource;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) 
    { return $this;
        $_product = $observer->getProduct();

        if(is_object($_product)){
            $connection  = $this->resource->getConnection();
            $tableName   = $connection->getTableName("catalog_product_option_type_value");
            $productStockInfo = $this->stockItemRepository->get($_product->getId());
            //Enable/Disable product custom options
            if($productStockInfo->getQty() > 0 && $productStockInfo->getIsInStock()){
                $data['disabled'] = 0;
            }else{
                $data['disabled'] = 1;
            }
            $where = ['sku = ?' => $_product->getSku()];
            $connection->update($tableName, $data, $where);
        }
        return $this;
    }
}
