<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Eviaglobal\AdvancedProductOptions\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Framework\Stdlib\ArrayManager;
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\CustomOptions;

class Area extends AbstractModifier implements \MageWorx\OptionBase\Ui\DataProvider\Product\Form\Modifier\ModifierInterface
{
    const FIELD_AREA_NAME = 'area';

    /**
     * @var ArrayManager
     */
    protected $arrayManager;

    /**
     * @var \MageWorx\OptionInventory\Helper\Data
     */
    protected $helperData;

    /**
     * @var array
     */
    protected $meta = [];

    /**
     * @param ArrayManager $arrayManager
     */
    public function __construct(
        ArrayManager $arrayManager,
        \MageWorx\OptionInventory\Helper\Data $helperData
    ) {
        $this->arrayManager = $arrayManager;
        $this->helperData   = $helperData;
    }

    /**
     * Get sort order of modifier to load modifiers in the right order
     *
     * @return int
     */
    public function getSortOrder()
    {
        return 31;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyData(array $data)
    {
        return $data;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyMeta(array $meta)
    {
        $this->meta = $meta;

        $this->addAreaField();

	$this->addIsVariantField();
        //$this->addMaterialUnitsRequiredField();
       
        return $this->meta;
    }

    protected function addIsVariantField(){
        $groupCustomOptionsName    = CustomOptions::GROUP_CUSTOM_OPTIONS_NAME;
        $optionContainerName       = CustomOptions::CONTAINER_OPTION;
        $commonOptionContainerName = CustomOptions::CONTAINER_COMMON_NAME;

        $isVariantField = $this->getIsVariantField();
         $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
        [$optionContainerName]['children'][$commonOptionContainerName]['children'] = array_replace_recursive(
            $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
            [$optionContainerName]['children'][$commonOptionContainerName]['children'],
            $isVariantField
        );
    }

    protected function getIsVariantField(){
        $fields = [
            'is_variant' => [
                'arguments' => [
                    'data' => [
                        'config'  => [
                            'label'         => __('Is Variant'),
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'formElement'   => \Magento\Ui\Component\Form\Element\Checkbox::NAME,
                            'dataScope'     => 'is_variant',
                            'dataType'      => \Magento\Ui\Component\Form\Element\DataType\Text::NAME,
                            'fit'           => true,
                            /*'validation'    => [
                                'validate-number' => true,
                            ],*/
                            'sortOrder'     => 50,
                            'visible'       => true,
                            'valueMap' => [
                                'true' => '1',
                                'false' => '0',
                            ]
                        ],
                        'imports' => [
                            'seeminglyArbitraryValue' => '${ $.provider }:data.form_id_field_name',
                        ],
                        'exports' => [
                            'seeminglyArbitraryValue' => '${ $.externalProvider }:params.form_id_field_name',
                        ],
                    ],
                ],
            ]
        ];

        return $fields;
    }

    protected function addMaterialUnitsRequiredField(){
        $groupCustomOptionsName    = CustomOptions::GROUP_CUSTOM_OPTIONS_NAME;
        $optionContainerName       = CustomOptions::CONTAINER_OPTION;
        $commonOptionContainerName = CustomOptions::CONTAINER_COMMON_NAME;

        $materialUnitsRequiredField = $this->getMaterialUnitsRequiredField();
         $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
        [$optionContainerName]['children'][$commonOptionContainerName]['children'] = array_replace_recursive(
            $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
            [$optionContainerName]['children'][$commonOptionContainerName]['children'],
            $materialUnitsRequiredField
        );
    }

    protected function addAreaField()
    {
        $groupCustomOptionsName =
            \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\CustomOptions::GROUP_CUSTOM_OPTIONS_NAME;
        $inventoryFields        = $this->getAreaField();

        $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
        ['container_option']['children']['values']['children']['record']['children'] = array_replace_recursive(
            $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
            ['container_option']['children']['values']['children']['record']['children'],
            $inventoryFields
        );
    }

    protected function getMaterialUnitsRequiredField()
    {
        $fields = [
            'material_units_required' => [
                'arguments' => [
                    'data' => [
                        'config'  => [
                            'label'         => __('Material/Units Required'),
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'formElement'   => \Magento\Ui\Component\Form\Element\Input::NAME,
                            'dataScope'     => 'material_units_required',
                            'dataType'      => \Magento\Ui\Component\Form\Element\DataType\Number::NAME,
                            'fit'           => true,
                            /*'validation'    => [
                                'validate-number' => true,
                            ],*/
                            'sortOrder'     => 21,
                            'visible'       => true
                        ],
                        'imports' => [
                            'seeminglyArbitraryValue' => '${ $.provider }:data.form_id_field_name',
                        ],
                        'exports' => [
                            'seeminglyArbitraryValue' => '${ $.externalProvider }:params.form_id_field_name',
                        ],
                    ],
                ],
            ]
        ];

        return $fields;
    }

    /**
     * Create additional custom options fields
     *
     * @return array
     */
    protected function getAreaField()
    {
        $fields = [
            'area'          => [
                'arguments' => [
                    'data' => [
                        'config'  => [
                            'label'         => __('Area'),
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'formElement'   => \Magento\Ui\Component\Form\Element\Input::NAME,
                            'dataScope'     => static::FIELD_AREA_NAME,
                            'dataType'      => \Magento\Ui\Component\Form\Element\DataType\Number::NAME,
                            'fit'           => true,
                            'validation'    => [
                                'validate-number' => true,
                            ],
                            'sortOrder'     => 21,
                            'visible'       => true
                        ],
                        'imports' => [
                            'seeminglyArbitraryValue' => '${ $.provider }:data.form_id_field_name',
                        ],
                        'exports' => [
                            'seeminglyArbitraryValue' => '${ $.externalProvider }:params.form_id_field_name',
                        ],
                    ],
                ],
            ]
        ];

        return $fields;
    }

    /**
     * Check is current modifier for the product only
     *
     * @return bool
     */
    public function isProductScopeOnly()
    {
        return false;
    }
}
