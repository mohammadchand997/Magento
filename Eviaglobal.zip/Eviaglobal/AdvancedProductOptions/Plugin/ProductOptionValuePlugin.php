<?php

namespace Eviaglobal\AdvancedProductOptions\Plugin;

use MageWorx\OptionDependency\Model\ResourceModel\Config as dependencyManager;


class ProductOptionValuePlugin {
    /**
     * @var MageWorx\OptionDependency\Model\ResourceModel\Config
     */
    protected $dependencyManager;

    public function __construct(
        dependencyManager $dependencyManager){
        $this->dependencyManager = $dependencyManager;
    }

    public function afterGetPrice(\Magento\Catalog\Model\Product\Option\Value $subject, $result, $flag = false){
        //Get current optionId dependent option id
        /*$connection = $this->dependencyManager->getConnection();
        $select = $connection->select()->from(
            $this->dependencyManager->getTable(\MageWorx\OptionDependency\Model\Config::TABLE_NAME),
            ['dp_parent_option_type_id']
        )->where(
            'dp_child_option_type_id = ' . $subject->getOptionTypeId()
        );
        $row = $connection->fetchAll($select);
        //Get dependent option area
        if($row){
            $dependentOptionId = $row[0]['dp_parent_option_type_id'];
            $select = $connection->select()->from(
                $this->dependencyManager->getTable('catalog_product_option_type_value'),
                ['area']
            )->where(
                'option_type_id = ' . $dependentOptionId
            );
            $res = $connection->fetchAll($select);
            if($res){
                $dependentOptionArea = $res[0]['area'];
                return $result * $dependentOptionArea;
            }
	}*/
        return $result;
    }
}

