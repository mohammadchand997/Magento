<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Api\Data;

interface BusinessCategorySearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get business_category list.
     * @return \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface[]
     */
    public function getItems();

    /**
     * Set name list.
     * @param \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

