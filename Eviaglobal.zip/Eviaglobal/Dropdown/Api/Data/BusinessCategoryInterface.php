<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Api\Data;

interface BusinessCategoryInterface
{

    const NAME = 'name';
    const BUSINESS_CATEGORY_ID = 'business_category_id';

    /**
     * Get business_category_id
     * @return string|null
     */
    public function getBusinessCategoryId();

    /**
     * Set business_category_id
     * @param string $businessCategoryId
     * @return \Eviaglobal\Dropdown\BusinessCategory\Api\Data\BusinessCategoryInterface
     */
    public function setBusinessCategoryId($businessCategoryId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Eviaglobal\Dropdown\BusinessCategory\Api\Data\BusinessCategoryInterface
     */
    public function setName($name);
}

