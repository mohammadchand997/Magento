<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model;

use Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface;
use Magento\Framework\Model\AbstractModel;

class BusinessCategory extends AbstractModel implements BusinessCategoryInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Eviaglobal\Dropdown\Model\ResourceModel\BusinessCategory::class);
    }

    /**
     * @inheritDoc
     */
    public function getBusinessCategoryId()
    {
        return $this->getData(self::BUSINESS_CATEGORY_ID);
    }

    /**
     * @inheritDoc
     */
    public function setBusinessCategoryId($businessCategoryId)
    {
        return $this->setData(self::BUSINESS_CATEGORY_ID, $businessCategoryId);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }
}

