<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model;

use Eviaglobal\Dropdown\Api\BusinessCategoryRepositoryInterface;
use Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface;
use Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterfaceFactory;
use Eviaglobal\Dropdown\Api\Data\BusinessCategorySearchResultsInterfaceFactory;
use Eviaglobal\Dropdown\Model\ResourceModel\BusinessCategory as ResourceBusinessCategory;
use Eviaglobal\Dropdown\Model\ResourceModel\BusinessCategory\CollectionFactory as BusinessCategoryCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class BusinessCategoryRepository implements BusinessCategoryRepositoryInterface
{

    /**
     * @var ResourceBusinessCategory
     */
    protected $resource;

    /**
     * @var BusinessCategoryInterfaceFactory
     */
    protected $businessCategoryFactory;

    /**
     * @var BusinessCategoryCollectionFactory
     */
    protected $businessCategoryCollectionFactory;

    /**
     * @var BusinessCategory
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;


    /**
     * @param ResourceBusinessCategory $resource
     * @param BusinessCategoryInterfaceFactory $businessCategoryFactory
     * @param BusinessCategoryCollectionFactory $businessCategoryCollectionFactory
     * @param BusinessCategorySearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceBusinessCategory $resource,
        BusinessCategoryInterfaceFactory $businessCategoryFactory,
        BusinessCategoryCollectionFactory $businessCategoryCollectionFactory,
        BusinessCategorySearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->businessCategoryFactory = $businessCategoryFactory;
        $this->businessCategoryCollectionFactory = $businessCategoryCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(
        BusinessCategoryInterface $businessCategory
    ) {
        try {
            $this->resource->save($businessCategory);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the businessCategory: %1',
                $exception->getMessage()
            ));
        }
        return $businessCategory;
    }

    /**
     * @inheritDoc
     */
    public function get($businessCategoryId)
    {
        $businessCategory = $this->businessCategoryFactory->create();
        $this->resource->load($businessCategory, $businessCategoryId);
        if (!$businessCategory->getId()) {
            throw new NoSuchEntityException(__('business_category with id "%1" does not exist.', $businessCategoryId));
        }
        return $businessCategory;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->businessCategoryCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(
        BusinessCategoryInterface $businessCategory
    ) {
        try {
            $businessCategoryModel = $this->businessCategoryFactory->create();
            $this->resource->load($businessCategoryModel, $businessCategory->getBusinessCategoryId());
            $this->resource->delete($businessCategoryModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the business_category: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($businessCategoryId)
    {
        return $this->delete($this->get($businessCategoryId));
    }
}

