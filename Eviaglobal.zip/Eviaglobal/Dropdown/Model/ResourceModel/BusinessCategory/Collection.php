<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model\ResourceModel\BusinessCategory;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'business_category_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Eviaglobal\Dropdown\Model\BusinessCategory::class,
            \Eviaglobal\Dropdown\Model\ResourceModel\BusinessCategory::class
        );
    }
}

