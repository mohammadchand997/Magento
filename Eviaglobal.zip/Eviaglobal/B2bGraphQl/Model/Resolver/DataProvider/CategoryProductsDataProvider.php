<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider;

class CategoryProductsDataProvider
{
    /**
     * @var  \Magento\Catalog\Model\CategoryFactory $categoryFactory
     */
     protected $categoryFactory;
     
     /**
      * @param \Magento\Catalog\Model\Product $productFactory
      */
      protected $productFactory;
      
    /**
     * 
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */  
    protected  $productRepository;
    
    /**
     * 
     * @var \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory
     */
    protected $optionCollection;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $collectionFactory;


    /**
     * 
     * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionCollection
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory
     */
    public function __construct(      
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionCollection,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory  $collectionFactory
    )
    {    
        $this->categoryFactory = $categoryFactory;
        $this->productFactory = $productFactory;
        $this->productRepository = $productRepository;
        $this->optionCollection = $optionCollection;
        $this->collectionFactory = $collectionFactory;
    }
    
    public function getCategoryData($params)
    {
        try {
            if(isset($params['search'])){
                $category = $this->getCategoryCollectionByName($params['search']);
            }elseif(isset($params['category_id'])){
                $category = $this->getCategoryCollectionById($params['category_id']);
            }else{
                return null;
            }
            if(!empty($category)){
                $categoryData ['category_name'] = $category->getName();
                $categoryData ['category_id'] = $category->getId();
                $categoryData ['count'] = $category->getProductCollection()->count();
                $categoryProducts = $category->getProductCollection()
                        ->addAttributeToSelect('*')
                        ->setPageSize($params['page_size'])
                        ->setCurPage($params['current_page']);
                $i = 0;
                if(!empty($categoryProducts)){
                    foreach ($categoryProducts as $product) {
                        // get Product data
                        $categoryData ['products'][$i]['product_id'] = $product->getEntityId();
                        $categoryData ['products'][$i]['product_name'] = $product->getName();
                        $categoryData ['products'][$i]['preview_image'] = $product->getThumbnail();
                        $categoryData ['products'][$i]['sku'] = $product->getSku();
                        $categoryData ['products'][$i]['price'] = $product->getPrice();
                        if($product->getIsIndependet()== 0){
                            $categoryData ['products'][$i]['variation'] = $this->getProductCustomOption($product->getSku());
                        }
                        $i++;
                    }
                    return $categoryData;
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
         return null;
    }
    
    public function getProductCustomOption($sku)
    {
        try {
            try {
                $product = $this->productRepository->get('MEG2');
            } catch (\Exception $exception) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
            }
            $productOption = $this->optionCollection->create()->getProductOptions($product->getEntityId(),$product->getStoreId(),false);
            $optionData = [];
            $j = 0;
            foreach($productOption as $option) {
                $optionId = $option->getId();
                $optionValues = $product->getOptionById($optionId);
                if ($optionValues === null) {
                    throw \Magento\Framework\Exception\NoSuchEntityException::singleField('optionId', $optionId);
                }
                foreach($optionValues->getValues() as $values) {
                    $optionData[$j]['size']['sku'] = $values->getSku();
                    $optionData[$j]['size']['value'] = $values->getDefaultTitle();
                    $j++;
                }
            }
            return $optionData;
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
        }
        return $optionData;
    }
    
    public function getCategoryCollectionById($categoryId){
        $categoryCollection = $this->categoryFactory->create()->load($categoryId);
        return $categoryCollection;
    }
    
    public function getCategoryCollectionByName($categoryName){
        echo"test...";
       $productCollection = $this->productFactory->create()->getCollection()->addAttributeToSelect(array('*'));
       print_r($productCollection->getData());
//        $collection = $productCollection->addAttributeToSelect('name')->addFieldToFilter('name', array('like' => '% '.$categoryName.' %'));
//               print_r($collection->getData());
       exit;
    }
}
