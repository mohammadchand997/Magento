<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class CategoryProducts implements ResolverInterface
{
    private $categoryProductsDataProvider;

    public function __construct(
            \Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider\CategoryProductsDataProvider $categoryProductsDataProvider
    ) {
        $this->categoryProductsDataProvider = $categoryProductsDataProvider;
    }

    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {

        /** @var ContextInterface $context */
        if (false === $context->getExtensionAttributes()->getIsCustomer()) {
            throw new GraphQlAuthorizationException(__('The current customer isn\'t authorized.'));
        }

        $result = $this->categoryProductsDataProvider->getCategoryData($args);
        return $result;
    }
}
