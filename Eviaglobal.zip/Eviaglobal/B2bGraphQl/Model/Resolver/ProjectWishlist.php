<?php

namespace Eviaglobal\B2bGraphQl\Model;

class ProjectWishlist
{

}
