<?php
/**
 * Copyright © 2017 BORN . All rights reserved.
 */
namespace Eviaglobal\Category\Observer\Backend\Catalog;
 
use \Magento\Framework\Event\Observer;
use \Magento\Framework\Event\ObserverInterface;
 
class CategoryPrepareSave implements ObserverInterface
{
    const ATTR_ADVERTISEMENT_BLOCK_CODE = 'advertisement_block';
 
    /**
     * @var  \Magento\Framework\App\RequestInterface
     */
    protected $request;
 
    /**
     * Constructor
     */
    public function __construct(
        \Magento\Framework\App\RequestInterface $request
    )
    {
        $this->request = $request;
    }
 
    public function execute(Observer $observer)
    {

        /** @var $product \Magento\Catalog\Model\Product */
        $product = $observer->getEvent()->getDataObject();
        $post = $this->request->getPost();
        $post = $post['advertisement_block'];
        $highlights = isset($post[self::ATTR_ADVERTISEMENT_BLOCK_CODE]) ? $post[self::ATTR_ADVERTISEMENT_BLOCK_CODE] : '';
        $product->setdvertisement_block($highlights);
        $requiredParams = ['sku','position'];
        if (is_array($highlights)) {
            $highlights = $this->removeEmptyArray($highlights, $requiredParams);
            $product->setAttractionHighlights(json_encode($highlights));
        }
    }
 
    /**
    * Function to remove empty array from the multi dimensional array
    *
    * @return Array
    */
    private function removeEmptyArray($attractionData, $requiredParams){
 
        $requiredParams = array_combine($requiredParams, $requiredParams);
        $reqCount = count($requiredParams);
 
        foreach ($attractionData as $key => $values) {
            $values = array_filter($values);
            $inersectCount = count(array_intersect_key($values, $requiredParams));
            if ($reqCount != $inersectCount) {
                unset($attractionData[$key]);
            }  
        }
        return $attractionData;
    }
}