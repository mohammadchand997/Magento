<?php
declare(strict_types=1);

namespace Eviaglobal\Category\Helper;

use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\ProductRepository;

class Data extends AbstractHelper
{
	protected $_categoryCollectionFactory;
	protected $_categoryFactory;
    protected $imageHelper; 
    protected $productRepository;   
    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        CollectionFactory $categoryCollectionFactory,
        CategoryFactory $categoryFactory,
        Image $imageHelper,
        ProductRepository $productRepository
    ) {
    	$this->_categoryCollectionFactory = $categoryCollectionFactory;
    	$this->_categoryFactory = $categoryFactory;
        $this->imageHelper = $imageHelper;
        $this->productRepository = $productRepository;
        parent::__construct($context);
    }

    

    public function getattributeByCategory($categoryIds, $page = 0) {
        if($page > 0 ){
            $page -= 1;
        }
        $categories = $this->getCategoryCollection($categoryIds); 


        $attrData = '';
        foreach ($categories as $category) {
            $attrData = $this->getCategoryData($category->getId(), 'advertisement_block');
        }
        if(!$attrData){
          return '';  
        }

		$getSku = explode(",",$attrData);

        $getProduct = [];
        foreach ($getSku as $sku) {

            $product = $this->getProductBySku($sku);
            $data['id'] = $product->getId();
            $data['name'] = $product->getName();
            $data['url'] = $product->getProductUrl();
            $data['sku'] = $product->getSku();
            $data['image'] = $product->getImage();
            $data['product_thumbnail_image'] = $this->imageHelper->init($product, 'product_base_image')->getUrl();
            $data['description'] = $product->getDescription();
            array_push($getProduct, $data);
        }
        $chunk_data = array_chunk($getProduct, 2);
        $passData = array_key_exists($page,$chunk_data) ? $chunk_data[$page] : '';
		return $passData;
        
    }

    public function getProductBySku($sku)
    {
        return $this->productRepository->get($sku);
    }

    public function getCategoryCollection($categoryIds) {
        $collection = $this->_categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addIsActiveFilter(); 
        $collection->addAttributeToFilter('entity_id', $categoryIds);
        return $collection;
    }

    public function getCategoryData($categoryId, $attrCode)
    {
        $category = $this->_categoryFactory->create()->load($categoryId);
        $categoryAttributeName = $category->getData($attrCode);
        return $categoryAttributeName;
    }
}
