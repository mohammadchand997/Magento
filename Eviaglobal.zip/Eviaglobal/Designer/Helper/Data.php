<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Customer\Api\GroupRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;

class Data extends AbstractHelper
{

    const XML_PATH_IS_ACTIVE = "designer/general/is_active";


   /**
   * @var \Magento\Framework\App\Config\ScopeConfigInterface
   */
   protected $scopeConfig;

    /**
     * \Magento\Eav\Model\Entity\Attribute
     */
    protected $attribute;

    protected $eavConfig;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Entity\Attribute $attribute,
        \Magento\Eav\Model\Config $eavConfig,
        GroupRepositoryInterface $groupRepository,
        CustomerSession $customerSession
    ){
        $this->scopeConfig = $scopeConfig;
        $this->attribute   = $attribute;
        $this->eavConfig   = $eavConfig;
        $this->groupRepository = $groupRepository;
        $this->customerSession = $customerSession;
        parent::__construct($context);
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_IS_ACTIVE, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getGroupName(){

        $getGroupId = $this->customerSession->getCustomer()->getGroupId();
        $group = $this->groupRepository->getById($getGroupId);
        $groupname = $group->getCode();
        return $groupname;

    }
}
