<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Model;

use Eviaglobal\Designer\Api\DesignerRepositoryInterface;
use Eviaglobal\Designer\Api\Data\DesignerInterface;
use Eviaglobal\Designer\Api\Data\DesignerInterfaceFactory;
use Eviaglobal\Designer\Api\Data\DesignerSearchResultsInterfaceFactory;
use Eviaglobal\Designer\Model\ResourceModel\Designer as ResourceDesigner;
use Eviaglobal\Designer\Model\ResourceModel\Designer\CollectionFactory as DesignerCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class DesignerRepository implements DesignerRepositoryInterface
{

    /**
     * @var DesignerCollectionFactory
     */
    protected $designerCollectionFactory;

    /**
     * @var Designer
     */
    protected $searchResultsFactory;

    /**
     * @var DesignerInterfaceFactory
     */
    protected $designerFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var ResourceDesigner
     */
    protected $resource;


    /**
     * @param ResourceDesigner $resource
     * @param DesignerInterfaceFactory $designerFactory
     * @param DesignerCollectionFactory $designerCollectionFactory
     * @param DesignerSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceDesigner $resource,
        DesignerInterfaceFactory $designerFactory,
        DesignerCollectionFactory $designerCollectionFactory,
        DesignerSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->designerFactory = $designerFactory;
        $this->designerCollectionFactory = $designerCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(DesignerInterface $designer)
    {
        try {
            $this->resource->save($designer);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the designer: %1',
                $exception->getMessage()
            ));
        }
        return $designer;
    }

    /**
     * @inheritDoc
     */
    public function get($designerId)
    {
        $designer = $this->designerFactory->create();
        $this->resource->load($designer, $designerId);
        if (!$designer->getId()) {
            throw new NoSuchEntityException(__('Designer with id "%1" does not exist.', $designerId));
        }
        return $designer;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->designerCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(DesignerInterface $designer)
    {
        try {
            $designerModel = $this->designerFactory->create();
            $this->resource->load($designerModel, $designer->getDesignerId());
            $this->resource->delete($designerModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Designer: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($designerId)
    {
        return $this->delete($this->get($designerId));
    }
}

