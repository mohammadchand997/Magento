<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Model\Designer;

use Eviaglobal\Designer\Model\ResourceModel\Designer\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;

    protected $storeManager;


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection    = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager  = $storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
        }
        $data = $this->dataPersistor->get('eviaglobal_designer_designer');
        
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('eviaglobal_designer_designer');

            
        }
        if(isset($model) && isset($this->loadedData[$model->getId()])){
            $this->loadedData[$model->getId()]['general']['title'] = $this->loadedData[$model->getId()]['title'];
            $this->loadedData[$model->getId()]['general']['email'] = $this->loadedData[$model->getId()]['email'];
            $this->loadedData[$model->getId()]['general']['about'] = $this->loadedData[$model->getId()]['about'];
            $this->loadedData[$model->getId()]['general']['website_url'] = $this->loadedData[$model->getId()]['website_url'];
            $this->loadedData[$model->getId()]['general']['customer_id'] = $this->loadedData[$model->getId()]['customer_id'];
            $this->loadedData[$model->getId()]['general']['city'] = $this->loadedData[$model->getId()]['city'];
            $this->loadedData[$model->getId()]['general']['country_id'] = $this->loadedData[$model->getId()]['country_id'];

            
            $this->loadedData[$model->getId()]['media']['logo'][0]['url'] = $this->getMediaUrl().$this->loadedData[$model->getId()]['logo'];
            $this->loadedData[$model->getId()]['media']['logo'][0]['name'] = $this->loadedData[$model->getId()]['logo'];
            $this->loadedData[$model->getId()]['media']['logo'][0]['type'] = 'image/png';
            $this->loadedData[$model->getId()]['media']['logo'][0]['size'] = 1234;
            $this->loadedData[$model->getId()]['media']['logo'][0]['exists'] = 1;

            $this->loadedData[$model->getId()]['media']['banner'][0]['url'] = $this->getMediaUrl().$this->loadedData[$model->getId()]['banner'];
            $this->loadedData[$model->getId()]['media']['banner'][0]['name'] = $this->loadedData[$model->getId()]['banner'];
            $this->loadedData[$model->getId()]['media']['banner'][0]['type'] = 'image/png';
            $this->loadedData[$model->getId()]['media']['banner'][0]['size'] = 1234;
            $this->loadedData[$model->getId()]['media']['banner'][0]['exists'] = 1;
        }
        return $this->loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'tmp/imageUploader/images/';
        return $mediaUrl;
    }
}

