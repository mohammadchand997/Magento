<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Model\Config\Source;

class Customers implements \Magento\Framework\Option\ArrayInterface{

    protected $collection;


    public function __construct(
        \Magento\Customer\Model\Customer $customerCollection
    ){
        $this->collection = $customerCollection;
    }

    public function toOptionArray()
    {
        $customers = $this->collection->getCollection()
                        ->addAttributeToSelect("*")
                        ->load();
        $customerData[] = ['value' => '', 'label' => '--select--'];
        foreach($customers as $_customer){
            $customerData[] = [
                'value' => $_customer->getId(),
                'label' => $_customer->getEmail()
            ];
        }
        return $customerData;
    }
}

