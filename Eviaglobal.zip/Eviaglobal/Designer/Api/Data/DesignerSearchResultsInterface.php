<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Api\Data;

interface DesignerSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Designer list.
     * @return \Eviaglobal\Designer\Api\Data\DesignerInterface[]
     */
    public function getItems();

    /**
     * Set title list.
     * @param \Eviaglobal\Designer\Api\Data\DesignerInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

