<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Controller\Adminhtml\Designer;

use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        //echo '<pre>';print_r($data);die();
        if ($data) {

            $formData = [
                'title' => $data['general']['title'],
                'email' => $data['general']['email'],
                'website_url' => $data['general']['website_url'],
                'city'       => $data['general']['city'],
                'customer_id'  => $data['general']['customer_id'],
                'country_id' => $data['general']['country_id'],
                'about'      => $data['general']['about'],
                'logo'       => $data['media']['logo'][0]['name'],
                'banner'     => $data['media']['banner'][0]['name']
            ];

            $id = $this->getRequest()->getParam('designer_id');
            $formData['designer_id'] = $id;
            $model = $this->_objectManager->create(\Eviaglobal\Designer\Model\Designer::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Designer no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            
            $model->setData($formData);
        
            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the Designer.'));
                $this->dataPersistor->clear('eviaglobal_designer_designer');
                
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['designer_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Designer.'));
            }
        
            $this->dataPersistor->set('eviaglobal_designer_designer', $data);
            return $resultRedirect->setPath('*/*/edit', ['designer_id' => $this->getRequest()->getParam('designer_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}

