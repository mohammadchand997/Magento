<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface CatalogInterface
{

    const LAST_NAME = 'last_name';
    const EMAIL = 'email';
    const COLLECTION_ID = 'collection_id';
    const REGION_ID = 'region_id';
    const ZIPCODE = 'zipcode';
    const MOBILE = 'mobile';
    const CITY = 'city';
    const CATALOG_ID = 'catalog_id';
    const REGION = 'region';
    const BRAND_ID = 'brand_id';
    const COMPANY = 'company';
    const ADDRESS = 'address';
    const FIRST_NAME = 'first_name';
    const COUNTRY_ID = 'country_id';
    const PROFESSION = 'profession';

    /**
     * Get catalog_id
     * @return string|null
     */
    public function getCatalogId();

    /**
     * Set catalog_id
     * @param string $catalogId
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setCatalogId($catalogId);

    /**
     * Get brand_id
     * @return string|null
     */
    public function getBrandId();

    /**
     * Set brand_id
     * @param string $brandId
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setBrandId($brandId);

    /**
     * Get collection_id
     * @return string|null
     */
    public function getCollectionId();

    /**
     * Set collection_id
     * @param string $collectionId
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setCollectionId($collectionId);

    /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName();

    /**
     * Set first_name
     * @param string $firstName
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setFirstName($firstName);

    /**
     * Get last_name
     * @return string|null
     */
    public function getLastName();

    /**
     * Set last_name
     * @param string $lastName
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setLastName($lastName);

    /**
     * Get email
     * @return string|null
     */
    public function getEmail();

    /**
     * Set email
     * @param string $email
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setEmail($email);

    /**
     * Get mobile
     * @return string|null
     */
    public function getMobile();

    /**
     * Set mobile
     * @param string $mobile
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setMobile($mobile);

    /**
     * Get profession
     * @return string|null
     */
    public function getProfession();

    /**
     * Set profession
     * @param string $profession
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setProfession($profession);

    /**
     * Get company
     * @return string|null
     */
    public function getCompany();

    /**
     * Set company
     * @param string $company
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setCompany($company);

    /**
     * Get address
     * @return string|null
     */
    public function getAddress();

    /**
     * Set address
     * @param string $address
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setAddress($address);

    /**
     * Get country_id
     * @return string|null
     */
    public function getCountryId();

    /**
     * Set country_id
     * @param string $countryId
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setCountryId($countryId);

    /**
     * Get region_id
     * @return string|null
     */
    public function getRegionId();

    /**
     * Set region_id
     * @param string $regionId
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setRegionId($regionId);

    /**
     * Get region
     * @return string|null
     */
    public function getRegion();

    /**
     * Set region
     * @param string $region
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setRegion($region);

    /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setCity($city);

    /**
     * Get zipcode
     * @return string|null
     */
    public function getZipcode();

    /**
     * Set zipcode
     * @param string $zipcode
     * @return \Eviaglobal\Brand\Catalog\Api\Data\CatalogInterface
     */
    public function setZipcode($zipcode);
}

