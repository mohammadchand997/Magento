<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface VideoSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Video list.
     * @return \Eviaglobal\Brand\Api\Data\VideoInterface[]
     */
    public function getItems();

    /**
     * Set brand_id list.
     * @param \Eviaglobal\Brand\Api\Data\VideoInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
