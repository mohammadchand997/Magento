/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'Magento_Ui/js/form/components/insert-form'
], function (Insert) {
    'use strict';

    return Insert.extend({
        defaults: {
            listens: {
                responseData: 'onResponse'
            },
            modules: {
                collectionListing: '${ $.collectionListingProvider }',
                collectionModal: '${ $.collectionModalProvider }'
            }
        },

        /**
         * Close modal, reload brand collection listing
         *
         * @param {Object} responseData
         */
        onResponse: function (responseData) {
            

            if (!responseData.error) {
                this.collectionModal().closeModal();
                this.collectionListing().reload({
                    refresh: true
                });
            }
        }
    });
});
