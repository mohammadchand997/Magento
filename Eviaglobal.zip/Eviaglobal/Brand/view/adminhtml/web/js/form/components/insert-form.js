/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'Magento_Ui/js/form/components/insert-form'
], function (Insert) {
    'use strict';

    return Insert.extend({
        defaults: {
            listens: {
                responseData: 'onResponse'
            },
            modules: {
                videoListing: '${ $.videoListingProvider }',
                videoModal: '${ $.videoModalProvider }'
            }
        },

        /**
         * Close modal, reload brand video listing
         *
         * @param {Object} responseData
         */
        onResponse: function (responseData) {
            

            if (!responseData.error) {
                this.videoModal().closeModal();
                this.videoListing().reload({
                    refresh: true
                });
            }
        }
    });
});
