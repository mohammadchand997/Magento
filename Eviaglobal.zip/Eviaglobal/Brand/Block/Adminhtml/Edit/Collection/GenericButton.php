<?php
declare(strict_types=1);

namespace Eviaglobal\Brand\Block\Adminhtml\Edit\Collection;

use Eviaglobal\Brand\Model\CollectionFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Eviaglobal\Brand\Model\ResourceModel\Collection;
use Eviaglobal\Brand\Model\CollectionRepository;

/**
 * Class for common code for buttons on the create/edit address form
 */
class GenericButton
{
    /**
     * @var collectionFactory
     */
    private $collectionFactory;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var collection
     */
    private $collectionResourceModel;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var collectionRepository
     */
    private $collectionRepository;

    /**
     * @param AddressFactory $addressFactory
     * @param UrlInterface $urlBuilder
     * @param Address $addressResourceModel
     * @param RequestInterface $request
     * @param AddressRepository $addressRepository
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        UrlInterface $urlBuilder,
        Collection $collectionResourceModel,
        RequestInterface $request,
        CollectionRepository $collectionRepository
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->urlBuilder = $urlBuilder;
        $this->collectionResourceModel = $collectionResourceModel;
        $this->request = $request;
        $this->collectionRepository = $collectionRepository;
    }

    /**
     * Return collection Id.
     *
     * @return int|null
     */
    public function getcollectionId()
    {
        $collection = $this->collectionFactory->create();

        $collectionId = $this->request->getParam('collection_id');
        $this->collectionResourceModel->load(
            $collection,
            $collectionId
        );

        return $collection->getcollectionId() ?: null;
    }

    /**
     * Get customer id.
     *
     * @return int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getBrandId()
    {
        $collectionId = $this->request->getParam('collection_id');

        $collection = $this->collectionRepository->get($collectionId);

        return $collection->getParentId() ?: null;
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', array $params = []): string
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
}
