<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends AbstractHelper
{

    const XML_PATH_IS_ACTIVE = "brand/general/is_active";

    const XML_PATH_ASSOCIATED_ATTRIBUTE = "brand/general/attribute";

   /**
   * @var \Magento\Framework\App\Config\ScopeConfigInterface
   */
   protected $scopeConfig;

    /**
     * \Magento\Eav\Model\Entity\Attribute
     */
    protected $attribute;

    protected $eavConfig;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Entity\Attribute $attribute,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Framework\Filesystem\Driver\File $fileDriver,
        \Magento\Store\Model\StoreManagerInterface $storeManager, 
        \Magento\Framework\App\ResourceConnection $resource
    ){
        $this->scopeConfig = $scopeConfig;
        $this->attribute   = $attribute;
        $this->eavConfig   = $eavConfig;
        $this->fileDriver = $fileDriver;
        $this->_storeManager = $storeManager;
        $this->_resource = $resource;
        parent::__construct($context);
    }

    public function getAttribute(){
        return $this->scopeConfig->getValue(
            self::XML_PATH_ASSOCIATED_ATTRIBUTE, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getAttributeOptions(){
        $attributeId = $this->getAttribute();
        if($attributeId){
            $attributeCode = $this->attribute->load($attributeId)->getAttributeCode();
            if($attributeCode){
                $attribute = $this->eavConfig->getAttribute('catalog_product', $attributeCode);
                $options = $attribute->getSource()->getAllOptions();
                $options[0]['label'] = "-- Please Select --";
                return $options;
            }
        }
        return [];
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_IS_ACTIVE, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function createCustomProduct($value='')
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->create('\Magento\Catalog\Model\Product');
        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $_categoryFactory = $objectManager->get('Magento\Catalog\Model\CategoryFactory');
        $categoryTitle = 'Brands';
        $collection = $_categoryFactory->create()->getCollection()->addFieldToFilter('name', ['in' => $categoryTitle]);
        $categoryId = '299';
        if ($collection->getSize()) {
            $categoryId = $collection->getFirstItem()->getId();
        }
        $attributes = isset($value['attributes']) ? (array) json_decode($value['attributes']) : '';
        $spaces = isset($attributes['spaces']) ? $attributes['spaces'] : '';
        $styles = isset($attributes['styles']) ? $attributes['styles'] : '';
        $acrylic_stone = isset($attributes['acrylic_stone']) ? $attributes['acrylic_stone'] : '';

        $url = '';

        try {
            $setSKU = str_replace(' ', '_', $value['name']);
            $urlKey = $this->createUrlKey($value['name'], $setSKU);
            $sku = $this->createUrlKey($value['name'], $setSKU);
            $product->setName($value['name']);
            $product->setTypeId('simple');
            $product->setAttributeSetId(35);
            $product->setSku($sku);
            $product->setStatus(1);
            $product->setWebsiteIds([1]);
            $product->setVisibility(4);
            $product->setPrice([1]);
            $product->setUrlKey($urlKey);
            $product->setCategoryIds([$categoryId]);
            if ($this->fileDriver->isExists($url)){
                $product->addImageToMediaGallery($url, array('image', 'small_image', 'thumbnail'), false, false);
            }
            // $product->setImage($value['image']);
            // $product->setSmallImage($value['image']);
            // $product->setThumbnail($value['image']);
            $product->setData('spaces', $spaces);
            $product->setData('styles', $styles);
            $product->setData('acrylic_stone', $acrylic_stone);
            $product->setStockData(
                [
                    'use_config_manage_stock' => 0,
                    'manage_stock' => 1,
                    'min_sale_qty' => 1,
                    'max_sale_qty' => 2,
                    'is_in_stock' => 1,
                    'qty' => 1
                ]
            );
            $product->save();
            return $product->getId();
        } catch (Exception $ex) {
            echo $e->getMessage();
        }
    }

    public function addProductImageById($productId, $image)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $url = $directory->getPath('pub').$image;
        $product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        if ($this->fileDriver->isExists($url)){
            $product->addImageToMediaGallery($url, array('image', 'small_image', 'thumbnail'), false, false);
        }
        $product->save();
    }

    public function addProductAttributeValueById($productId, $attributeCode, $attributeValue)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        $product->setData($attributeCode, $attributeValue);
        $product->save();
    }

    public function increment_string($str, $separator = '-', $first = 1)
    {
        preg_match('/(.+)'.$separator.'([0-9]+)$/', $str, $match);
        return isset($match[2]) ? $match[1].$separator.($match[2] + 1) : $str.$separator.$first;
    }

    public function createUrlKey($title, $sku) 
    {
        $url = preg_replace('#[^0-9a-z]+#i', '-', $title);
        $urlKey = strtolower($url);
        $storeId = (int) $this->_storeManager->getStore()->getStoreId();
        
        $isUnique = $this->checkUrlKeyDuplicates($sku, $urlKey, $storeId);
        if ($isUnique) {
            return $urlKey;
        } else {
            return $urlKey . '-' . time();
        }
    }

    /*
     * Function to check URL Key Duplicates in Database
     */

    private function checkUrlKeyDuplicates($sku, $urlKey, $storeId) 
    {
        $urlKey .= '.html';

        $connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tablename = $connection->getTableName('url_rewrite');
        $sql = $connection->select()->from(
                        ['url_rewrite' => $connection->getTableName('url_rewrite')], ['request_path', 'store_id']
                )->joinLeft(
                        ['cpe' => $connection->getTableName('catalog_product_entity')], "cpe.entity_id = url_rewrite.entity_id"
                )->where('request_path IN (?)', $urlKey)
                ->where('store_id IN (?)', $storeId)
                ->where('cpe.sku not in (?)', $sku);

        $urlKeyDuplicates = $connection->fetchAssoc($sql);

        if (!empty($urlKeyDuplicates)) {
            return false;
        } else {
            return true;
        }
    }

    public function getBusinessCategoryFieldOptions(){

        $attribute = $this->eavConfig->getAttribute('catalog_product', 'business_category');
        $options = $attribute->getSource()->getAllOptions();
        $optionsExists = array();
        return $options;
    }

    public function getAreYouFieldOptions(){

        $attribute = $this->eavConfig->getAttribute('catalog_product', 'are_you');
        $options = $attribute->getSource()->getAllOptions();
        $optionsExists = array();
        return $options;
    }

    public function deleteProductById($id)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $product = $objectManager->create('Magento\Catalog\Model\Product');
        $product->load($id)->delete();
    }
}
