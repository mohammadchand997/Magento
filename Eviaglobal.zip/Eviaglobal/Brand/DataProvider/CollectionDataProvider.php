<?php

namespace Eviaglobal\Brand\DataProvider;

use Magento\Framework\App\Request\DataPersistorInterface;
use Eviaglobal\Brand\Model\ResourceModel\YourModel\CollectionFactory;
use Eviaglobal\Brand\Model\ResourceModel\Brand\Collection;

class CollectionDataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    protected $loadedData;
    protected $collection;
    protected $dataPersistor;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();
        foreach ($items as $item) {
            $this->loadedData[$item->getId()] = $item->getData();
            // Additional processing if needed to fetch media gallery data
            // For example, if you have stored image paths in JSON format, you can decode it here
            // $this->loadedData[$item->getId()]['gallery_collection'] = json_decode($item->getData('gallery_collection'), true);
        }

        $data = $this->dataPersistor->get('your_module_data');
        if (!empty($data)) {
            $item = $this->collection->getNewEmptyItem();
            $item->setData($data);
            $this->loadedData[$item->getId()] = $item->getData();
            $this->dataPersistor->clear('your_module_data');
        }

        return $this->loadedData;
    }
}

