<?php
namespace Eviaglobal\Brand\Controller\Catalog;

use Magento\Framework\View\Result\PageFactory;  
use Magento\Framework\Controller\Result\JsonFactory;
use Eviaglobal\Catalog\Model\CatalogFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;

class Save extends \Magento\Framework\App\Action\Action
{
    private $logger;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Psr\Log\LoggerInterface $logger,
        JsonFactory $resultJsonFactory,
        CatalogFactory $catalogFactory,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        TransportBuilder $transportBuilder
        
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->catalogFactory = $catalogFactory;
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_transportBuilder = $transportBuilder;
        $this->_logger = $logger;
        parent::__construct($context);
    }
    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        if ($this->getRequest()->isAjax()) 
        {
            $params = $this->getRequest()->getParams();
                try{
                    $catalogFactory = $this->catalogFactory->create();
                    $catalogFactory->setData($params);
                    $catalogFactory->save();
                    // $adminTo = [
                    //     'name' => $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE),
                    //     'email' => $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE)
                    // ];
                    // $userTo = [
                    //     'first_name' => $params['first_name'],
                    //     'email' => $params['email'],
                    // ];

                    // $this->sendAknowledgementEmail($params, '1', $userTo);
                
                    // $this->sendEmailToAdmin($params, '1', $adminTo);
                    $response =[
                        'status' => true,
                        'message' => '',
                    ];
                }catch(Exception $ex){
                    $response =[
                        'status' => false,
                        'message' => __('Something went wrong'),
                    ];
                }
            return $result->setData($response);
        }
    }

    public function sendEmailToAdmin($post, $templateId, $to)
    {
        $var = array(
            'store' => $this->_storeManager->getStore(),
            'first_name' => $post['first_name'], 
            'last_name' => $post['last_name'], 
            'email' => $post['email'], 
            'mobile' => $post['mobile'], 
            'country_id' => $post['country_id'], 
            'city' => $post['city']
        );
        try {
                $store = $this->_storeManager->getStore()->getId();
                $transport = $this->_transportBuilder->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => 'frontend', 'store' => $store])
                    ->setTemplateVars($var)
                    ->setFrom('general')
                    ->addTo($to['email'], $to['first_name'])
                    ->getTransport();
                $transport->sendMessage();
                return true;
            } catch (\Exception $e) {
                $this->_logger->critical($e->getMessage());
                return false;
            }
    }

    public function sendAknowledgementEmail($post, $templateId, $to)
    {
        $var = array(
            'store' => $this->_storeManager->getStore(),
            'first_name' => $post['first_name'], 
            'last_name' => $post['last_name'], 
            'email' => $post['email'], 
            'mobile' => $post['mobile'], 
            'country_id' => $post['country_id'], 
            'city' => $post['city']
        );
        try {
                $store = $this->_storeManager->getStore()->getId();
                $transport = $this->_transportBuilder->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => 'frontend', 'store' => $store])
                    ->setTemplateVars($var)
                    ->setFrom('general')
                    ->addTo($to['email'], $to['first_name'])
                    ->getTransport();
                $transport->sendMessage();
                return 'jsdkjffd';
            } catch (\Exception $e) {
                $this->_logger->critical($e->getMessage());
                return false;
            }
    }
}