<?php
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Collection;

use Magento\Backend\App\Action;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Eviaglobal\Brand\Api\CollectionRepositoryInterface;
use Psr\Log\LoggerInterface;

/**
 * Button for deletion of brand Collection in admin
 */
class Delete extends Action implements HttpPostActionInterface
{

    /**
     * @var CollectionRepositoryInterface
     */
    private $collectionRepository;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Action\Context $context
     * @param CollectionRepositoryInterface $collectionRepository
     * @param JsonFactory $resultJsonFactory
     * @param LoggerInterface $logger
     */
    public function __construct(
        Action\Context $context,
        CollectionRepositoryInterface $collectionRepository,
        JsonFactory $resultJsonFactory,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->collectionRepository   = $collectionRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
    }

    /**
     * Delete brand Collection action
     *
     * @return Json
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(): Json
    {
        $brandId = $this->getRequest()->getParam('parent_id', false);
        $collectionId = $this->getRequest()->getParam('collection_id', false);
        $error = false;
        $message = '';
        
        if ($collectionId && $this->collectionRepository->get($collectionId)->getParentId() === $brandId) {
            try {
                $this->collectionRepository->deleteById($collectionId);
                $message = __('You deleted the collection.');
            } catch (\Exception $e) {
                $error = true;
                $message = __('We can\'t delete the collection right now.');
                $this->logger->critical($e);
            }
        }

        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'message' => $message,
                'error' => $error,
            ]
        );

        return $resultJson;
    }
}
