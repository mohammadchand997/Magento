<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Collection;

use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\UrlInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Store\Model\StoreManagerInterface;
use Eviaglobal\Brand\Model\ImageUploader;


class GalleryUpload extends \Magento\Backend\App\Action
{
  /**
   *
   * @var UploaderFactory
   */
  protected $uploaderFactory;

  /** 
   * @var Filesystem\Directory\WriteInterface 
   */
  protected $mediaDirectory;
  
  /**
   * @var StoreManagerInterface
   */
  protected $storeManager;

  protected $imageUploader;

  public function __construct(
    Context $context,
    UploaderFactory $uploaderFactory,
    Filesystem $filesystem,
    StoreManagerInterface $storeManager,
    ImageUploader $imageUploader
  ){
    parent::__construct($context);
    $this->uploaderFactory = $uploaderFactory;
    $this->mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
    $this->storeManager = $storeManager;
    $this->imageUploader = $imageUploader;
  }

  public function execute()
  {
    try { 
            $docs = array();
            $docattchments = isset($_FILES['gallery_collection']) ? $_FILES['gallery_collection'] : array();
            foreach($docattchments as $key => $docattchment)
            {
                foreach($docattchment as $doc)
                {
                    if($key == 'name')
                    {
                        $docs['name'] = $doc['gallery_image'];
                    }
                    if($key == 'type')
                    {
                        $docs['type'] = $doc['gallery_image'];
                    }
                    if($key == 'tmp_name')
                    {
                        $docs['tmp_name'] = $doc['gallery_image'];
                    }
                    if($key == 'error')
                    {
                        $docs['error'] = $doc['gallery_image'];
                    }
                    if($key == 'size')
                    {
                        $docs['size'] = $doc['gallery_image'];
                    }
                }
            }
            $imageId = $this->getRequest()->getParam('param_name', 'gallery_collection');
            $result = $this->imageUploader->saveFileToTmpDir($docs);
        } catch (\Exception $e) {
            $result = ['error' => $e->getMessage(), 'errorcode' => $e->getCode()];
        }
    return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData($result);
  }
}

