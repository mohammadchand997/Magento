<?php

namespace Eviaglobal\Brand\Controller\Adminhtml\Brand;

use Magento\Framework\Controller\ResultFactory;

/**
 * Class Upload
 */
class GalleryUpload extends \Magento\Backend\App\Action
{
    /**
     * Image uploader
     *
     * @var \Magento\Catalog\Model\ImageUploader
     */
    protected $imageUploader;

    /**
     * Upload constructor.
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Catalog\Model\ImageUploader $imageUploader
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Eviaglobal\Brand\Model\ImageUploader $imageUploader
    ) {
        parent::__construct($context);
        $this->imageUploader = $imageUploader;
    }

    /**
     * Upload file controller action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        
        try {
            $value = array();
            $docs = array();
            $docattchments = isset($_FILES['media']) ? $_FILES['media'] : array();
            foreach($docattchments as $key => $docattchment)
            {
                foreach($docattchment as $value)
                {
                    foreach ($value['media_gallery'] as $doc) {
                        if($key == 'name')
                        {
                            $docs['name'] = $doc['gallery_image'];
                        }
                        if($key == 'type')
                        {
                            $docs['type'] = $doc['gallery_image'];
                        }
                        if($key == 'tmp_name')
                        {
                            $docs['tmp_name'] = $doc['gallery_image'];
                        }
                        if($key == 'error')
                        {
                            $docs['error'] = $doc['gallery_image'];
                        }
                        if($key == 'size')
                        {
                            $docs['size'] = $doc['gallery_image'];
                        }
                    }
                    
                }
            }
            // echo 'askajsd';
            // echo '<pre>';
            // print_r($docs);
            // die;

            $result = $this->imageUploader->saveFileToTmpDir($docs);
        } catch (\Exception $e) {
            $result = ['error' => $e->getMessage(), 'errorcode' => $e->getCode()];
        }
        return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData($result);
    }
}