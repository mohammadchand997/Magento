<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Profile;

use Magento\Customer\Model\Session;
use Eviaglobal\Brand\Model\BrandFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Directory\Model\CountryFactory;
use Magento\Catalog\Model\ResourceModel\ProductFactory;
use Magento\Framework\Pricing\Helper\Data as PricingHelper;

class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Session
     */
    protected $session;

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        PageFactory $resultPageFactory,
        BrandFactory $brandFactory,
        CountryFactory $countryFactory,
        ProductFactory $productFactory,
        PricingHelper $pricingHelper
    ) {
        $this->session = $customerSession;
        $this->resultPageFactory = $resultPageFactory;
        $this->brandFactory = $brandFactory;
        $this->_countryFactory = $countryFactory;
        $this->productFactory = $productFactory;
        $this->pricingHelper = $pricingHelper;
        parent::__construct($context);
    }

    /**
     * Customer register form page
     *
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $urlKey = $this->getRequest()->getParam('key');
        
        $id = $this->getBrandIdByUrlKey($urlKey);
        if(!$id){
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('/');
            return $resultRedirect;
        }
        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $brandData = $this->getBrandInfoById($id);
        $block = $resultPage->getLayout()->getBlock('brand_profile');
        $block->setData('brandData', $brandData);

        $meta_title = $brandData['meta_title'] ? $brandData['meta_title'] : '';
        $meta_keywords = $brandData['meta_keywords'] ? $brandData['meta_keywords'] : '';
        $meta_description = $brandData['meta_description'] ? $brandData['meta_description'] : '';

        $resultPage->getConfig()->getTitle()->set($meta_title); // meta title
        $resultPage->getConfig()->setKeywords($meta_keywords); // meta keywords
        $resultPage->getConfig()->setDescription($meta_description); // meta description
        return $resultPage;
    }

    public function getBrandInfoById($id)
    {

        $getBrandData = $this->brandFactory->create()->load($id);
        $brand = $getBrandData->getData();
        $attributes = (array)json_decode($brand['attributes'], true);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $price=$objectManager->create('Magento\Framework\Pricing\Helper\Data')->currency($brand['price_from']);
        $price_from = $brand['price_from'] ? $this->pricingHelper->currency($brand['price_from']) : '';
        $price_to = $brand['price_to'] ? $this->pricingHelper->currency($brand['price_to']) : '';
        
        $spaces = '';
        if(isset($attributes['spaces'])){
            $spaces = $this->getAttributeByOptionId('spaces', $attributes['spaces']);
        }
        $styles = '';
        if(isset($attributes['styles'])){
            $styles = $this->getAttributeByOptionId('styles', $attributes['styles']);
        }
        $getData = array(
            'brand_id' => $brand['brand_id'],
            'title' => $brand['title'], 
            'meta_title' => $brand['meta_title'], 
            'email' => $brand['email'], 
            'logo' => $brand['logo'], 
            'banner' => $brand['banner'], 
            'about' => $brand['about'],  
            'website_url' => $brand['website_url'], 
            'city' => $brand['city'], 
            'country' => $this->getCountryname($brand['country_id']),
            'spaces' => $spaces,
            'styles' => $styles,
            'price' => $price_from.' - '.$price_to,
            'meta_keywords' => $brand['meta_keywords'], 
            'meta_description' => $brand['meta_description']
        );
        // echo "<pre>";
        // print_r($getData);
        // die;
        return $getData;
    }

    public function getCountryname($countryCode){    
        $country = $this->_countryFactory->create()->loadByCode($countryCode);
        return $country->getName();
    }

    public function getAttributeByOptionId($attributeCode, $optionIds){

        $poductReource=$this->productFactory->create();
        $attribute = $poductReource->getAttribute($attributeCode);

        if ($attribute && $attribute->usesSource()) {

            $option_Text = [];
            foreach ($optionIds as $key => $optionId) {
                $option_Text[] = $attribute->getSource()->getOptionText($optionId);
            }
            return implode(",",$option_Text);
        }
    }

    public function getBrandIdByUrlKey($urlKey){
        $barnd = $this->brandFactory->create()->getCollection()->addFieldToFilter('url_key', $urlKey)->getFirstItem();
        return $barnd->getId();
    }
}


