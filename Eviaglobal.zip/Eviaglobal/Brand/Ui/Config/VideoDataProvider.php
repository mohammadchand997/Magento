<?php

declare(strict_types=1);

namespace Eviaglobal\Brand\Ui\Config;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Eviaglobal\Brand\Model\ResourceModel\Video\CollectionFactory;

/**
 * Class CustomDataProvider
 */
class VideoDataProvider extends AbstractDataProvider
{
    /**
     * @var array
     */
    private $loadedData;

    /**
     * CustomDataProvider constructor.
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();

        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (null !== $this->loadedData) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $video) {
            $this->loadedData[$video->getId()] = $video->getData();
        }
        return $this->loadedData;
    }
}
