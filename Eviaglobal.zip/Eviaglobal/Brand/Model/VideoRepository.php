<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model;

use Eviaglobal\Brand\Api\Data\VideoInterface;
use Eviaglobal\Brand\Api\Data\VideoInterfaceFactory;
use Eviaglobal\Brand\Api\Data\VideoSearchResultsInterfaceFactory;
use Eviaglobal\Brand\Api\VideoRepositoryInterface;
use Eviaglobal\Brand\Model\ResourceModel\Video as ResourceVideo;
use Eviaglobal\Brand\Model\ResourceModel\Video\CollectionFactory as VideoCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class VideoRepository implements VideoRepositoryInterface
{

    /**
     * @var VideoInterfaceFactory
     */
    protected $videoFactory;

    /**
     * @var ResourceVideo
     */
    protected $resource;

    /**
     * @var VideoCollectionFactory
     */
    protected $videoCollectionFactory;

    /**
     * @var Video
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;


    /**
     * @param ResourceVideo $resource
     * @param VideoInterfaceFactory $videoFactory
     * @param VideoCollectionFactory $videoCollectionFactory
     * @param VideoSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceVideo $resource,
        VideoInterfaceFactory $videoFactory,
        VideoCollectionFactory $videoCollectionFactory,
        VideoSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->videoFactory = $videoFactory;
        $this->videoCollectionFactory = $videoCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(VideoInterface $video)
    {
        try {
            $this->resource->save($video);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the video: %1',
                $exception->getMessage()
            ));
        }
        return $video;
    }

    /**
     * @inheritDoc
     */
    public function get($videoId)
    {
        $video = $this->videoFactory->create();
        $this->resource->load($video, $videoId);
        if (!$video->getId()) {
            throw new NoSuchEntityException(__('Video with id "%1" does not exist.', $videoId));
        }
        return $video;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->videoCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(VideoInterface $video)
    {
        try {
            $videoModel = $this->videoFactory->create();
            $this->resource->load($videoModel, $video->getVideoId());
            $this->resource->delete($videoModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Video: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($videoId)
    {
        return $this->delete($this->get($videoId));
    }
}
