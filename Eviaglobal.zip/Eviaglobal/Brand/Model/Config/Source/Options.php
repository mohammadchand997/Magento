<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model\Config\Source;
use \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;

class Options implements \Magento\Framework\Option\ArrayInterface
{
    protected $helper;


    public function __construct(
        \Eviaglobal\Brand\Helper\Data $helper
    ){
        $this->helper = $helper;
    }

    public function toOptionArray()
    {
        return $this->helper->getAttributeOptions();
    }
}
