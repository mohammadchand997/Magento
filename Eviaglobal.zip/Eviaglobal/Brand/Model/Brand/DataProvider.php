<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model\Brand;

use Eviaglobal\Brand\Model\ResourceModel\Brand\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem\DirectoryList;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;

    protected $storeManager;


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        File $fileDriver,
        DirectoryList $directory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection    = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager  = $storeManager;
        $this->fileDriver = $fileDriver;
        $this->directory = $directory;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
        }
        $data = $this->dataPersistor->get('eviaglobal_brand_brand');
        
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('eviaglobal_brand_brand');

            
        }
        // echo '<pre>';
        // print_r($this->loadedData[$model->getId()]);
        // die;
        if(isset($model) && isset($this->loadedData[$model->getId()])){

            $this->loadedData[$model->getId()]['general']['display_on_frontend'] = $this->loadedData[$model->getId()]['display_on_frontend'];
            $this->loadedData[$model->getId()]['general']['show_on_homepage'] = $this->loadedData[$model->getId()]['show_on_homepage'];
            $this->loadedData[$model->getId()]['general']['title'] = $this->loadedData[$model->getId()]['title'];
            $this->loadedData[$model->getId()]['general']['email'] = $this->loadedData[$model->getId()]['email'];
            $this->loadedData[$model->getId()]['general']['url_key'] = $this->loadedData[$model->getId()]['url_key'];
            $this->loadedData[$model->getId()]['general']['about'] = $this->loadedData[$model->getId()]['about'];
            $this->loadedData[$model->getId()]['general']['website_url'] = $this->loadedData[$model->getId()]['website_url'];

            // $this->loadedData[$model->getId()]['general']['option_id'] = $this->loadedData[$model->getId()]['option_id'];
            if($this->loadedData[$model->getId()]['attributes']){

                $attributes = (array)json_decode($this->loadedData[$model->getId()]['attributes']);
                $attributes['city'] = $this->loadedData[$model->getId()]['city'];
                $attributes['country_id'] = $this->loadedData[$model->getId()]['country_id'];
                $this->loadedData[$model->getId()]['attributes'] = $attributes;
            }
            $get = 'not null';
            
            $this->loadedData[$model->getId()]['general']['discounts'] = json_decode($this->loadedData[$model->getId()]['discounts']);
            if($this->loadedData[$model->getId()]['discounts'] == 'null'){
                $this->loadedData[$model->getId()]['general']['discounts'] = [];
            }

            
            // $logo = $this->directory->getPath('pub').'/media/tmp/imageUploader/images/'.$this->loadedData[$model->getId()]['logo'];
            if($this->loadedData[$model->getId()]['logo']){
                
                $this->loadedData[$model->getId()]['media']['logo'][0]['url'] = $this->getMediaUrl().$this->loadedData[$model->getId()]['logo'];
                $this->loadedData[$model->getId()]['media']['logo'][0]['name'] = $this->loadedData[$model->getId()]['logo'];
                $this->loadedData[$model->getId()]['media']['logo'][0]['type'] = 'image/png';
                $this->loadedData[$model->getId()]['media']['logo'][0]['size'] = 1234;
                $this->loadedData[$model->getId()]['media']['logo'][0]['exists'] = 1;  
            }

            if($this->loadedData[$model->getId()]['banner']){

                $this->loadedData[$model->getId()]['media']['banner'][0]['url'] = $this->getMediaUrl().$this->loadedData[$model->getId()]['banner'];
                $this->loadedData[$model->getId()]['media']['banner'][0]['name'] = $this->loadedData[$model->getId()]['banner'];
                $this->loadedData[$model->getId()]['media']['banner'][0]['type'] = 'image/png';
                $this->loadedData[$model->getId()]['media']['banner'][0]['size'] = 1234;
                $this->loadedData[$model->getId()]['media']['banner'][0]['exists'] = 1;
            }
            
            if($this->loadedData[$model->getId()]['listing_banner']){

                $this->loadedData[$model->getId()]['media']['listing_banner'][0]['url'] = $this->getMediaUrl().$this->loadedData[$model->getId()]['listing_banner'];
                $this->loadedData[$model->getId()]['media']['listing_banner'][0]['name'] = $this->loadedData[$model->getId()]['listing_banner'];
                $this->loadedData[$model->getId()]['media']['listing_banner'][0]['type'] = 'image/png';
                $this->loadedData[$model->getId()]['media']['listing_banner'][0]['size'] = 1234;
                $this->loadedData[$model->getId()]['media']['listing_banner'][0]['exists'] = 1;
            }

            if($this->loadedData[$model->getId()]['home_banner']){

                $this->loadedData[$model->getId()]['media']['home_banner'][0]['url'] = $this->getMediaUrl().$this->loadedData[$model->getId()]['home_banner'];
                $this->loadedData[$model->getId()]['media']['home_banner'][0]['name'] = $this->loadedData[$model->getId()]['home_banner'];
                $this->loadedData[$model->getId()]['media']['home_banner'][0]['type'] = 'image/png';
                $this->loadedData[$model->getId()]['media']['home_banner'][0]['size'] = 1234;
                $this->loadedData[$model->getId()]['media']['home_banner'][0]['exists'] = 1;
            }

            $this->loadedData[$model->getId()]['others_detail']['contact_name'] = $this->loadedData[$model->getId()]['contact_name'];
            $this->loadedData[$model->getId()]['others_detail']['designation'] = $this->loadedData[$model->getId()]['designation'];
            $this->loadedData[$model->getId()]['others_detail']['business_category'] = $this->loadedData[$model->getId()]['business_category'];
            $this->loadedData[$model->getId()]['others_detail']['are_you'] = $this->loadedData[$model->getId()]['are_you'];
            $this->loadedData[$model->getId()]['others_detail']['postcode'] = $this->loadedData[$model->getId()]['postcode'];
            $this->loadedData[$model->getId()]['others_detail']['address_1'] = $this->loadedData[$model->getId()]['address_1'];
            $this->loadedData[$model->getId()]['others_detail']['address_2'] = $this->loadedData[$model->getId()]['address_2'];
            $this->loadedData[$model->getId()]['others_detail']['phone'] = $this->loadedData[$model->getId()]['phone'];
            $this->loadedData[$model->getId()]['others_detail']['email_c'] = $this->loadedData[$model->getId()]['email_c'];
            $this->loadedData[$model->getId()]['others_detail']['meta_title'] = $this->loadedData[$model->getId()]['meta_title'];
            $this->loadedData[$model->getId()]['others_detail']['meta_keywords'] = $this->loadedData[$model->getId()]['meta_keywords'];
            $this->loadedData[$model->getId()]['others_detail']['meta_description'] = $this->loadedData[$model->getId()]['meta_description'];

            $getMediaGallery = $this->loadedData[$model->getId()]['media_gallery'];
            $decodeMediaGallery = $getMediaGallery ? json_decode($getMediaGallery) : '';

            $this->loadedData[$model->getId()]['media']['media_gallery'] = $decodeMediaGallery;
        }
        return $this->loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'tmp/imageUploader/images/';
        return $mediaUrl;
    }
}

