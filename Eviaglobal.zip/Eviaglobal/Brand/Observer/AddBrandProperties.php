<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Observer;

use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Event\Observer;
use Magento\Config\Model\Config\Source\Yesno;

class AddBrandProperties implements ObserverInterface
{
    /**
     * @var Registry
     */
    protected $_registry;

    /**
     * @var Yesno
     */
    protected $_yesNo;

    public function __construct(
        Yesno $yesNo,
        \Magento\Framework\Registry $registry,
    ) {
        $this->_yesNo    = $yesNo;
        $this->_registry = $registry;
    }


    public function execute(Observer $observer)
    {
        $form     = $observer->getForm();
        $fieldset = $form->getElement('advanced_fieldset');
        $yesno    = $this->_yesNo->toOptionArray();
        $attributeObject = $this->_registry->registry('entity_attribute');
        $fieldset->addField(
            'used_in_brand_form',
            'select',
            [
                'name' => 'used_in_brand_form',
                'label' => __('Use in Brand Form'),
                'title' => __('Use in Brand Form'),
                'values' => $yesno,
                'value' => $attributeObject->getData('used_in_brand_form') ?: 0
            ]
        );
        $fieldset->addField(
            'used_in_brand_detail',
            'select',
            [
                'name' => 'used_in_brand_detail',
                'label' => __('Use in Brand Detail Page'),
                'title' => __('Use in Brand Detail Page'),
                'values' => $yesno,
                'value' => $attributeObject->getData('used_in_brand_detail') ?: 0
            ]
        );
        $fieldset->addField(
            'brand_detail_sort_order',
            'text',
            [
                'name' => 'brand_detail_sort_order',
                'label' => __('Brand Detail Sort Order'),
                'title' => __('Brand Detail Sort Order'),
                'value' => $attributeObject->getData('brand_detail_sort_order') ?: ''
            ]
        );

        //echo "<pre>";print_r(get_class_methods($fieldset));die();
    }
}
