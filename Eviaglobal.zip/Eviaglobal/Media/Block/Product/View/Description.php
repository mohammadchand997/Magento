<?php
namespace Eviaglobal\Media\Block\Product\View;


class Description extends \Magento\Catalog\Block\Product\View\Description
{
    const OPTION_TYPE_VALUE_TABLE = 'catalog_product_option_type_value';
    /**
     * @return Product
     */
    public function getProduct()
    {
        $variant = $this->getRequest()->getParam('variant');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resourceConnection = $objectManager->get('\Magento\Framework\App\ResourceConnection');
        $connection  = $resourceConnection->getConnection();
        $table       = $connection->getTableName(self::OPTION_TYPE_VALUE_TABLE);

        if($variant){
            $query = $connection->select()
                        ->from($table,['sku'])
                        ->where('option_type_id = ?', $variant);
            $fetchData = $connection->fetchCol($query);
            $sku = $fetchData[0] ?? 0;
            if($sku){
                $productRepository = $objectManager->get('\Magento\Catalog\Api\ProductRepositoryInterface');
                return $productRepository->get($sku);
            }else{
                return parent::getProduct();
            }
        }
        return parent::getProduct();
    }
}