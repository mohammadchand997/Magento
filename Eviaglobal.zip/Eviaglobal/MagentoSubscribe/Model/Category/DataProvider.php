<?php
namespace Eviaglobal\MagentoSubscribe\Model\Category;
 
class DataProvider extends \Magento\Catalog\Model\Category\DataProvider
{
 
    protected function getFieldsMap()
    {
        $fields = parent::getFieldsMap();
        $fields['content'][] = 'mobile_banner'; // custom image field
        
        return $fields;
    }
}