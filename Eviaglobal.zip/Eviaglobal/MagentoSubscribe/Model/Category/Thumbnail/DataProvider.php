<?php
namespace Eviaglobal\MagentoSubscribe\Model\Category\Thumbnail;
 
class DataProvider extends \Magento\Catalog\Model\Category\DataProvider
{
 
    protected function getFieldsMap()
    {
        $fields = parent::getFieldsMap();
        $fields['content'][] = 'thumbnail_image'; // custom image field
        
        return $fields;
    }
}